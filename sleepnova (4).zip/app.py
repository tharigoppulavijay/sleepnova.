"""
SleepNova Standalone Flask Web Server
Run locally with:
    pip install -r requirements.txt
    python app.py
"""

from __future__ import annotations

import os
from pathlib import Path
import secrets

from flask import Flask, Response, jsonify, render_template, request, send_file, session

import config
from backend.analytics import (
    compute_executive_summary,
    compute_monthly_analytics,
    compute_weekly_analytics,
)
from backend.plotting import generate_sleep_chart
from backend.reports import build_report_data, export_report_file
from backend.sleep_logic import calculate_duration
from backend.storage import (
    clear_all_records,
    delete_record,
    export_csv,
    export_json,
    import_csv,
    load_records,
    load_settings,
    reset_to_demo_data,
    save_record,
    save_settings,
    search_records,
    update_record,
)
from backend.validation import ValidationError

app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.environ.get("SLEEPNOVA_SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 4 * 1024 * 1024  # 4 MB upload guard


def _ensure_csrf_token() -> str:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return str(session["csrf_token"])


def _verify_csrf() -> bool:
    if request.method in ("GET", "HEAD", "OPTIONS"):
        return True
    expected = session.get("csrf_token")
    provided = request.headers.get("X-CSRF-Token") or request.form.get("csrf_token")
    if expected and provided and secrets.compare_digest(str(expected), str(provided)):
        return True
    # Also allow same-origin fetch with X-Requested-With in local browser workflows
    return request.headers.get("X-Requested-With") == "SleepNova-Client"


def _ensure_seeded() -> list[dict]:
    if not config.RECORDS_JSON_PATH.exists() and not config.RECORDS_CSV_PATH.exists():
        return reset_to_demo_data()
    records = load_records()
    assert isinstance(records, list)
    return records


@app.before_request
def csrf_guard() -> Response | None:
    if request.path.startswith("/api/") and request.method in ("POST", "PUT", "DELETE", "PATCH"):
        if not _verify_csrf():
            return jsonify({"ok": False, "error": "CSRF verification failed."}), 403
    return None


@app.after_request
def add_security_headers(response: Response) -> Response:
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    return response


@app.context_processor
def inject_globals() -> dict[str, object]:
    return {"csrf_token": _ensure_csrf_token(), "app_name": config.APP_NAME}


# ---------------------------------------------------------------------------
# Page Routes
# ---------------------------------------------------------------------------
@app.get("/")
def page_landing() -> str:
    return render_template("index.html", active_page="landing")


@app.get("/dashboard")
def page_dashboard() -> str:
    return render_template("dashboard.html", active_page="dashboard")


@app.get("/logger")
def page_logger() -> str:
    return render_template("logger.html", active_page="logger")


@app.get("/history")
def page_history() -> str:
    return render_template("history.html", active_page="history")


@app.get("/analytics")
def page_analytics() -> str:
    return render_template("analytics.html", active_page="analytics")


@app.get("/reports")
def page_reports() -> str:
    return render_template("reports.html", active_page="reports")


@app.get("/settings")
def page_settings() -> str:
    return render_template("settings.html", active_page="settings")


@app.get("/about")
def page_about() -> str:
    return render_template("about.html", active_page="about")


# ---------------------------------------------------------------------------
# API Routes
# ---------------------------------------------------------------------------
@app.get("/api/health")
def api_health() -> Response:
    records = _ensure_seeded()
    return jsonify({"ok": True, "engine": "flask-python", "record_count": len(records)})


@app.get("/api/records")
def api_get_records() -> Response:
    _ensure_seeded()
    min_h = request.args.get("min_hours")
    max_h = request.args.get("max_hours")
    page = request.args.get("page", "1")
    page_size = request.args.get("page_size", "0")
    sort_order = request.args.get("sort", "newest")
    if sort_order not in ("newest", "oldest", "longest", "shortest"):
        return jsonify({"ok": False, "error": "Unsupported sort order."}), 400
    try:
        result = search_records(
            keyword=request.args.get("keyword", ""),
            date_query=request.args.get("date", ""),
            start_date=request.args.get("start_date", ""),
            end_date=request.args.get("end_date", ""),
            min_hours=float(min_h) if min_h not in (None, "") else None,
            max_hours=float(max_h) if max_h not in (None, "") else None,
            sort_order=sort_order,
            page=int(page),
            page_size=int(page_size),
        )
        return jsonify({"ok": True, **result})
    except ValueError:
        return jsonify({"ok": False, "error": "Invalid query parameter value."}), 400


@app.post("/api/records/preview")
def api_preview_duration() -> Response:
    payload = request.get_json(silent=True) or {}
    try:
        calc = calculate_duration(
            str(payload.get("sleep_date", "")),
            str(payload.get("bedtime", "")),
            str(payload.get("wake_date", "")),
            str(payload.get("wake_time", "")),
        )
        return jsonify({"ok": True, **calc})
    except ValueError as exc:
        return jsonify({"ok": False, "error": str(exc)}), 400


@app.post("/api/records")
def api_create_record() -> tuple[Response, int]:
    _ensure_seeded()
    payload = request.get_json(silent=True) or {}
    try:
        created = save_record(payload)
        return jsonify({"ok": True, "record": created}), 201
    except ValidationError as exc:
        return jsonify({"ok": False, "error": exc.message, "field_errors": exc.field_errors}), 400


@app.put("/api/records/<record_id>")
def api_update_record(record_id: str) -> tuple[Response, int]:
    _ensure_seeded()
    payload = request.get_json(silent=True) or {}
    try:
        updated = update_record(record_id, payload)
        return jsonify({"ok": True, "record": updated}), 200
    except ValidationError as exc:
        return jsonify({"ok": False, "error": exc.message, "field_errors": exc.field_errors}), 400
    except KeyError as exc:
        return jsonify({"ok": False, "error": str(exc).strip("'")}), 404


@app.delete("/api/records/<record_id>")
def api_delete_record(record_id: str) -> tuple[Response, int]:
    _ensure_seeded()
    try:
        deleted = delete_record(record_id)
        return jsonify({"ok": True, "deleted": deleted}), 200
    except ValidationError as exc:
        return jsonify({"ok": False, "error": exc.message}), 400
    except KeyError as exc:
        return jsonify({"ok": False, "error": str(exc).strip("'")}), 404


@app.get("/api/analytics/summary")
def api_analytics_summary() -> Response:
    records = _ensure_seeded()
    settings = load_settings()
    return jsonify({"ok": True, **compute_executive_summary(records, settings)})


@app.get("/api/analytics/weekly")
def api_analytics_weekly() -> Response:
    records = _ensure_seeded()
    settings = load_settings()
    return jsonify({"ok": True, **compute_weekly_analytics(records, settings)})


@app.get("/api/analytics/monthly")
def api_analytics_monthly() -> Response:
    records = _ensure_seeded()
    settings = load_settings()
    return jsonify({"ok": True, **compute_monthly_analytics(records, settings)})


@app.get("/api/export/csv")
def api_export_csv() -> Response:
    records = _ensure_seeded()
    content = export_csv(records)
    return Response(
        content,
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=sleepnova_records.csv"},
    )


@app.get("/api/export/json")
def api_export_json() -> Response:
    records = _ensure_seeded()
    content = export_json(records)
    return Response(
        content,
        mimetype="application/json; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=sleepnova_records.json"},
    )


ALLOWED_PERIODS = {"daily", "weekly", "monthly", "all"}
ALLOWED_FORMATS = {"csv", "json", "markdown", "txt", "text", "audit", "png"}
ALLOWED_CHARTS = {
    "weekly_trend",
    "monthly_trend",
    "duration_distribution",
    "goal_progress",
    "consistency_trend",
}


@app.get("/api/reports/preview")
def api_report_preview() -> tuple[Response, int] | Response:
    records = _ensure_seeded()
    settings = load_settings()
    period = request.args.get("period", "weekly").lower()
    if period not in ALLOWED_PERIODS:
        return jsonify({"ok": False, "error": "Unsupported report period."}), 400
    return jsonify({"ok": True, **build_report_data(records, settings, period=period)})


@app.get("/api/reports/export")
def api_report_export() -> tuple[Response, int] | Response:
    records = _ensure_seeded()
    settings = load_settings()
    period = request.args.get("period", "weekly").lower()
    fmt = request.args.get("format", "markdown").lower()
    if period not in ALLOWED_PERIODS:
        return jsonify({"ok": False, "error": "Unsupported report period."}), 400
    if fmt not in ALLOWED_FORMATS:
        return jsonify({"ok": False, "error": "Unsupported report format."}), 400
    res = export_report_file(records, settings, period=period, export_format=fmt)
    if res.get("is_binary"):
        target = Path(str(res["path"])).resolve()
        if not str(target).startswith(str(config.EXPORTS_DIR) + os.sep):
            return jsonify({"ok": False, "error": "Invalid export path."}), 400
        return send_file(target, mimetype="image/png", as_attachment=True, download_name=res["filename"])
    return Response(
        str(res["content"]),
        mimetype=str(res["mime"]),
        headers={"Content-Disposition": f'attachment; filename="{res["filename"]}"'},
    )


@app.get("/api/charts/<chart_kind>")
def api_chart_png(chart_kind: str) -> tuple[Response, int] | Response:
    if chart_kind not in ALLOWED_CHARTS:
        return jsonify({"ok": False, "error": "Unsupported chart type."}), 400
    records = _ensure_seeded()
    settings = load_settings()
    meta = generate_sleep_chart(records, settings, chart_kind=chart_kind)
    target = Path(str(meta["path"])).resolve()
    if not str(target).startswith(str(config.EXPORTS_DIR) + os.sep):
        return jsonify({"ok": False, "error": "Invalid chart path."}), 400
    return send_file(target, mimetype="image/png")


@app.post("/api/import/csv")
def api_import_csv() -> tuple[Response, int]:
    _ensure_seeded()
    preview_only = False
    if "file" in request.files:
        uploaded = request.files["file"]
        filename = (uploaded.filename or "").strip()
        if filename and not filename.lower().endswith(".csv"):
            return jsonify({"ok": False, "error": "Only .csv files are permitted for bulk import."}), 400
        csv_text = uploaded.read().decode("utf-8", errors="replace")
        preview_only = str(request.form.get("preview_only", "")).lower() == "true"
    else:
        payload = request.get_json(silent=True) or {}
        csv_text = str(payload.get("csv_content", ""))
        preview_only = bool(payload.get("preview_only", False))

    try:
        result = import_csv(csv_text, preview_only=preview_only)
        return jsonify({"ok": True, **result}), 200
    except ValidationError as exc:
        return jsonify({"ok": False, "error": exc.message}), 400
    except PermissionError:
        return jsonify({"ok": False, "error": "Storage permission denied while importing records."}), 500


@app.get("/api/settings")
def api_get_settings() -> Response:
    return jsonify({"ok": True, "settings": load_settings()})


@app.put("/api/settings")
def api_save_settings() -> tuple[Response, int]:
    payload = request.get_json(silent=True) or {}
    try:
        saved = save_settings(payload)
        return jsonify({"ok": True, "settings": saved}), 200
    except ValidationError as exc:
        return jsonify({"ok": False, "error": exc.message, "field_errors": exc.field_errors}), 400


@app.post("/api/demo/reset")
def api_reset_demo() -> Response:
    records = reset_to_demo_data()
    return jsonify({"ok": True, "record_count": len(records)})


@app.post("/api/records/clear")
def api_clear_records() -> Response:
    removed = clear_all_records()
    return jsonify({"ok": True, "removed_count": removed})


if __name__ == "__main__":
    config.ensure_directories()
    _ensure_seeded()
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=False)
