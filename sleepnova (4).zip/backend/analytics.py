"""Statistical analytics, consistency scoring, and executive summary engine."""

from __future__ import annotations

from datetime import date, datetime, timedelta
import math
import statistics
from typing import Any

from .sleep_logic import (
    compute_bedtime_offset_minutes,
    format_duration,
    minutes_to_hhmm,
    offset_minutes_to_hhmm,
    time_to_minutes,
)
from .warnings import evaluate_warnings


def _safe_mean(values: list[float]) -> float:
    return round(statistics.mean(values), 2) if values else 0.0


def _safe_stdev(values: list[float]) -> float:
    return round(statistics.stdev(values), 2) if len(values) >= 2 else 0.0


def _period_filter(
    records: list[dict[str, Any]],
    start_date: date,
    end_date: date,
) -> list[dict[str, Any]]:
    s_iso = start_date.isoformat()
    e_iso = end_date.isoformat()
    return [
        r
        for r in records
        if s_iso <= str(r.get("wake_date", r.get("sleep_date", ""))) <= e_iso
    ]


def compute_consistency_metrics(records: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Compute bedtime and wake-up regularity using circular midnight-aware offsets.

    Formula explanation:
    - Bedtime offsets are measured in minutes relative to midnight (e.g., 22:30 -> -90m, 00:30 -> +30m).
    - Wake-up times are measured in minutes since 00:00.
    - Regularity index (0-100%) maps the combined standard deviation against a 150-minute reference spread:
      score = max(0, min(100, round(100 * (1 - avg_stdev_minutes / 150)))).
    This is a statistical schedule consistency metric, not a medical assessment.
    """
    if len(records) < 2:
        return {
            "sufficient_data": False,
            "record_count": len(records),
            "consistency_score": None,
            "rating_label": "Insufficient data",
            "average_bedtime": records[0]["bedtime"] if records else None,
            "average_wake_time": records[0]["wake_time"] if records else None,
            "bedtime_stdev_minutes": None,
            "wake_stdev_minutes": None,
            "explanation": (
                "At least 2 sleep records are required to compute bedtime and wake-up variation."
            ),
        }

    bed_offsets = [float(compute_bedtime_offset_minutes(str(r["bedtime"]))) for r in records]
    wake_mins = [float(time_to_minutes(str(r["wake_time"]))) for r in records]

    avg_bed_offset = statistics.mean(bed_offsets)
    avg_wake_mins = statistics.mean(wake_mins)
    bed_stdev = statistics.stdev(bed_offsets)
    wake_stdev = statistics.stdev(wake_mins)

    combined_stdev = (bed_stdev + wake_stdev) / 2.0
    score = max(0, min(100, round(100.0 * (1.0 - (combined_stdev / 150.0)))))

    if score >= 80:
        rating = "Highly Consistent"
    elif score >= 60:
        rating = "Moderately Consistent"
    elif score >= 40:
        rating = "Variable"
    else:
        rating = "Irregular"

    return {
        "sufficient_data": True,
        "record_count": len(records),
        "consistency_score": score,
        "rating_label": rating,
        "average_bedtime": offset_minutes_to_hhmm(avg_bed_offset),
        "average_wake_time": minutes_to_hhmm(avg_wake_mins),
        "bedtime_stdev_minutes": round(bed_stdev, 1),
        "wake_stdev_minutes": round(wake_stdev, 1),
        "explanation": (
            "Calculated from the standard deviation of midnight-centered bedtime offsets "
            "and wake-up clock times across stored records. Higher values indicate smaller "
            "day-to-day schedule drift; this is a statistical indicator, not a medical assessment."
        ),
    }


def _compute_period_stats(
    records: list[dict[str, Any]],
    goal_hours: float,
) -> dict[str, Any]:
    """Compute core descriptive statistics for any subset of sleep records."""
    if not records:
        return {
            "record_count": 0,
            "total_minutes": 0,
            "total_hours": 0.0,
            "total_formatted": "0h 00m",
            "average_minutes": 0,
            "average_hours": 0.0,
            "average_formatted": "0h 00m",
            "median_hours": 0.0,
            "longest_session": None,
            "shortest_session": None,
            "goal_hours": goal_hours,
            "goal_met_count": 0,
            "goal_achievement_pct": 0.0,
            "duration_stdev_hours": 0.0,
        }

    durations_min = [int(r["duration_minutes"]) for r in records]
    durations_hr = [float(r["duration_hours"]) for r in records]

    total_min = sum(durations_min)
    avg_min = round(statistics.mean(durations_min))
    avg_hr = round(statistics.mean(durations_hr), 2)
    med_hr = round(statistics.median(durations_hr), 2)

    longest = max(records, key=lambda r: int(r["duration_minutes"]))
    shortest = min(records, key=lambda r: int(r["duration_minutes"]))

    goal_met = sum(1 for h in durations_hr if h >= goal_hours)
    goal_pct = round((goal_met / len(records)) * 100.0, 1)

    return {
        "record_count": len(records),
        "total_minutes": total_min,
        "total_hours": round(total_min / 60.0, 2),
        "total_formatted": format_duration(total_min),
        "average_minutes": avg_min,
        "average_hours": avg_hr,
        "average_formatted": format_duration(avg_min),
        "median_hours": med_hr,
        "longest_session": {
            "id": longest["id"],
            "sleep_date": longest["sleep_date"],
            "wake_date": longest["wake_date"],
            "duration_hours": longest["duration_hours"],
            "duration_minutes": longest["duration_minutes"],
            "formatted": format_duration(int(longest["duration_minutes"])),
        },
        "shortest_session": {
            "id": shortest["id"],
            "sleep_date": shortest["sleep_date"],
            "wake_date": shortest["wake_date"],
            "duration_hours": shortest["duration_hours"],
            "duration_minutes": shortest["duration_minutes"],
            "formatted": format_duration(int(shortest["duration_minutes"])),
        },
        "goal_hours": goal_hours,
        "goal_met_count": goal_met,
        "goal_achievement_pct": goal_pct,
        "duration_stdev_hours": _safe_stdev(durations_hr),
    }


def compute_weekly_analytics(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    reference_date: date | None = None,
) -> dict[str, Any]:
    """Compute 7-day rolling weekly analytics and previous-7-day comparison."""
    today = reference_date or date.today()
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))

    curr_start = today - timedelta(days=6)
    prev_end = curr_start - timedelta(days=1)
    prev_start = prev_end - timedelta(days=6)

    curr_records = _period_filter(records, curr_start, today)
    prev_records = _period_filter(records, prev_start, prev_end)

    curr_stats = _compute_period_stats(curr_records, goal_hours)
    prev_stats = _compute_period_stats(prev_records, goal_hours)

    # Daily breakdown for exact 7-day calendar window (null for missing days—never fabricated!)
    by_wake_date: dict[str, list[dict[str, Any]]] = {}
    for rec in curr_records:
        key = str(rec.get("wake_date", rec.get("sleep_date")))
        by_wake_date.setdefault(key, []).append(rec)

    daily_series: list[dict[str, Any]] = []
    for offset in range(6, -1, -1):
        day_obj = today - timedelta(days=offset)
        day_iso = day_obj.isoformat()
        day_recs = by_wake_date.get(day_iso, [])
        if day_recs:
            total_mins = sum(int(r["duration_minutes"]) for r in day_recs)
            daily_series.append(
                {
                    "date": day_iso,
                    "label": day_obj.strftime("%a %m/%d"),
                    "short_day": day_obj.strftime("%a"),
                    "duration_hours": round(total_mins / 60.0, 2),
                    "duration_minutes": total_mins,
                    "bedtime": day_recs[0]["bedtime"],
                    "wake_time": day_recs[0]["wake_time"],
                    "has_record": True,
                }
            )
        else:
            daily_series.append(
                {
                    "date": day_iso,
                    "label": day_obj.strftime("%a %m/%d"),
                    "short_day": day_obj.strftime("%a"),
                    "duration_hours": None,
                    "duration_minutes": None,
                    "bedtime": None,
                    "wake_time": None,
                    "has_record": False,
                }
            )

    avg_delta_hours = (
        round(curr_stats["average_hours"] - prev_stats["average_hours"], 2)
        if curr_records and prev_records
        else None
    )
    total_delta_hours = (
        round(curr_stats["total_hours"] - prev_stats["total_hours"], 2)
        if curr_records and prev_records
        else None
    )

    return {
        "period_start": curr_start.isoformat(),
        "period_end": today.isoformat(),
        "previous_start": prev_start.isoformat(),
        "previous_end": prev_end.isoformat(),
        "stats": curr_stats,
        "previous_stats": prev_stats,
        "comparison": {
            "average_delta_hours": avg_delta_hours,
            "total_delta_hours": total_delta_hours,
            "record_count_delta": curr_stats["record_count"] - prev_stats["record_count"],
        },
        "daily_series": daily_series,
        "consistency": compute_consistency_metrics(curr_records),
        "missing_days_count": sum(1 for d in daily_series if not d["has_record"]),
    }


def compute_monthly_analytics(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    reference_date: date | None = None,
) -> dict[str, Any]:
    """Compute 30-day rolling monthly analytics, weekly buckets, and duration distribution."""
    today = reference_date or date.today()
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))

    curr_start = today - timedelta(days=29)
    prev_end = curr_start - timedelta(days=1)
    prev_start = prev_end - timedelta(days=29)

    curr_records = _period_filter(records, curr_start, today)
    prev_records = _period_filter(records, prev_start, prev_end)

    curr_stats = _compute_period_stats(curr_records, goal_hours)
    prev_stats = _compute_period_stats(prev_records, goal_hours)

    # 30-day chronological series (missing days remain null)
    by_wake_date: dict[str, list[dict[str, Any]]] = {}
    for rec in curr_records:
        key = str(rec.get("wake_date", rec.get("sleep_date")))
        by_wake_date.setdefault(key, []).append(rec)

    daily_series: list[dict[str, Any]] = []
    for offset in range(29, -1, -1):
        day_obj = today - timedelta(days=offset)
        day_iso = day_obj.isoformat()
        day_recs = by_wake_date.get(day_iso, [])
        if day_recs:
            total_mins = sum(int(r["duration_minutes"]) for r in day_recs)
            daily_series.append(
                {
                    "date": day_iso,
                    "label": day_obj.strftime("%b %d"),
                    "duration_hours": round(total_mins / 60.0, 2),
                    "bedtime": day_recs[0]["bedtime"],
                    "wake_time": day_recs[0]["wake_time"],
                    "has_record": True,
                }
            )
        else:
            daily_series.append(
                {
                    "date": day_iso,
                    "label": day_obj.strftime("%b %d"),
                    "duration_hours": None,
                    "bedtime": None,
                    "wake_time": None,
                    "has_record": False,
                }
            )

    # Weekly comparison across 4 trailing 7-day blocks
    weekly_comparison: list[dict[str, Any]] = []
    for week_idx in range(3, -1, -1):
        w_end = today - timedelta(days=week_idx * 7)
        w_start = w_end - timedelta(days=6)
        w_recs = _period_filter(records, w_start, w_end)
        w_stats = _compute_period_stats(w_recs, goal_hours)
        weekly_comparison.append(
            {
                "label": f"{w_start.strftime('%b %d')}–{w_end.strftime('%b %d')}",
                "start_date": w_start.isoformat(),
                "end_date": w_end.isoformat(),
                "record_count": w_stats["record_count"],
                "average_hours": w_stats["average_hours"],
                "total_hours": w_stats["total_hours"],
            }
        )

    # Duration distribution buckets across stored monthly records
    buckets = [
        {"label": "< 5h", "min": 0.0, "max": 5.0, "count": 0},
        {"label": "5h – 6h", "min": 5.0, "max": 6.0, "count": 0},
        {"label": "6h – 7h", "min": 6.0, "max": 7.0, "count": 0},
        {"label": "7h – 8h", "min": 7.0, "max": 8.0, "count": 0},
        {"label": "8h – 9h", "min": 8.0, "max": 9.0, "count": 0},
        {"label": "9h+", "min": 9.0, "max": 99.0, "count": 0},
    ]
    for rec in curr_records:
        hrs = float(rec["duration_hours"])
        for bucket in buckets:
            if bucket["min"] <= hrs < bucket["max"]:
                bucket["count"] += 1
                break

    # Consistency time series across recorded sessions (oldest to newest)
    chronological = sorted(
        curr_records,
        key=lambda r: (str(r["sleep_date"]), str(r["bedtime"])),
    )
    consistency_series = [
        {
            "date": r["sleep_date"],
            "wake_date": r["wake_date"],
            "bedtime": r["bedtime"],
            "wake_time": r["wake_time"],
            "bedtime_offset_hours": round(
                compute_bedtime_offset_minutes(str(r["bedtime"])) / 60.0, 2
            ),
            "wake_time_hours": round(time_to_minutes(str(r["wake_time"])) / 60.0, 2),
            "duration_hours": r["duration_hours"],
        }
        for r in chronological
    ]

    avg_delta_hours = (
        round(curr_stats["average_hours"] - prev_stats["average_hours"], 2)
        if curr_records and prev_records
        else None
    )

    return {
        "period_start": curr_start.isoformat(),
        "period_end": today.isoformat(),
        "stats": curr_stats,
        "previous_stats": prev_stats,
        "comparison": {
            "average_delta_hours": avg_delta_hours,
            "record_count_delta": curr_stats["record_count"] - prev_stats["record_count"],
        },
        "daily_series": daily_series,
        "weekly_comparison": weekly_comparison,
        "distribution": buckets,
        "consistency_series": consistency_series,
        "consistency": compute_consistency_metrics(curr_records),
    }


def compute_executive_summary(
    records: list[dict[str, Any]],
    settings: dict[str, Any],
    reference_date: date | None = None,
) -> dict[str, Any]:
    """
    Generate complete Daily, Weekly, Monthly, and Overall analytical summaries
    along with data quality indicators and threshold warnings.
    """
    today = reference_date or date.today()
    goal_hours = float(settings.get("sleep_goal_hours", 8.0))

    daily_records = _period_filter(records, today, today)
    if not daily_records and records:
        # Also report latest logged session explicitly without mislabeling its date
        latest_session = records[0]
    else:
        latest_session = daily_records[0] if daily_records else None

    weekly = compute_weekly_analytics(records, settings, reference_date=today)
    monthly = compute_monthly_analytics(records, settings, reference_date=today)
    overall_stats = _compute_period_stats(records, goal_hours)
    overall_consistency = compute_consistency_metrics(records)
    warnings = evaluate_warnings(records, settings, reference_date=today)

    # Trend direction comparing last 7 days vs prior 7 days
    delta = weekly["comparison"]["average_delta_hours"]
    if delta is None:
        trend_status = "Baseline Building"
        trend_detail = "Log entries across at least two consecutive weeks to establish a week-over-week trend."
    elif delta >= 0.25:
        trend_status = "Increasing Duration"
        trend_detail = f"Average sleep duration increased by +{delta:.2f}h compared to the previous 7 days."
    elif delta <= -0.25:
        trend_status = "Decreasing Duration"
        trend_detail = f"Average sleep duration decreased by {delta:.2f}h compared to the previous 7 days."
    else:
        trend_status = "Stable"
        trend_detail = f"Average sleep duration remained steady ({delta:+.2f}h) compared to the previous 7 days."

    # Data quality assessment
    demo_count = sum(1 for r in records if r.get("is_demo"))
    user_count = len(records) - demo_count
    if records:
        dates = sorted(str(r["sleep_date"]) for r in records)
        span_days = (
            datetime.strptime(dates[-1], "%Y-%m-%d").date()
            - datetime.strptime(dates[0], "%Y-%m-%d").date()
        ).days + 1
        coverage_pct = round(min(100.0, (len(records) / max(1, span_days)) * 100.0), 1)
    else:
        dates = []
        span_days = 0
        coverage_pct = 0.0

    # Personalized, neutral, data-derived informational insights (non-diagnostic)
    insights: list[dict[str, str]] = []
    if records:
        weekday_hrs: list[float] = []
        weekend_hrs: list[float] = []
        for rec in records:
            try:
                wd = datetime.strptime(str(rec["wake_date"]), "%Y-%m-%d").weekday()
                hrs = float(rec["duration_hours"])
                if wd in (5, 6):
                    weekend_hrs.append(hrs)
                else:
                    weekday_hrs.append(hrs)
            except (KeyError, ValueError):
                continue

        if weekday_hrs and weekend_hrs:
            wd_avg = statistics.mean(weekday_hrs)
            we_avg = statistics.mean(weekend_hrs)
            diff_wk = we_avg - wd_avg
            insights.append(
                {
                    "title": "Weekday vs. Weekend Pattern",
                    "detail": (
                        f"Weekend sessions average {we_avg:.2f}h compared to {wd_avg:.2f}h on weekdays "
                        f"({diff_wk:+.2f}h difference across {len(records)} recorded sessions)."
                    ),
                }
            )

        insights.append(
            {
                "title": f"Goal Alignment ({goal_hours:.1f}h Target)",
                "detail": (
                    f"{overall_stats['goal_met_count']} of {overall_stats['record_count']} sessions "
                    f"({overall_stats['goal_achievement_pct']}%) met or exceeded your {goal_hours:.1f}h target."
                ),
            }
        )

        if overall_consistency["sufficient_data"]:
            insights.append(
                {
                    "title": "Schedule Window Observation",
                    "detail": (
                        f"Your mean sleep window runs from {overall_consistency['average_bedtime']} to "
                        f"{overall_consistency['average_wake_time']} with a bedtime spread of "
                        f"±{overall_consistency['bedtime_stdev_minutes']} minutes."
                    ),
                }
            )
    else:
        insights.append(
            {
                "title": "Ready for First Entry",
                "detail": "Log at least two sleep sessions to unlock weekday/weekend comparisons and consistency insights.",
            }
        )

    # Goal progress series across 4 trailing weekly blocks
    goal_progress_weekly = []
    for wk in monthly["weekly_comparison"]:
        w_start = datetime.strptime(wk["start_date"], "%Y-%m-%d").date()
        w_end = datetime.strptime(wk["end_date"], "%Y-%m-%d").date()
        w_recs = _period_filter(records, w_start, w_end)
        w_stats = _compute_period_stats(w_recs, goal_hours)
        goal_progress_weekly.append(
            {
                "label": wk["label"],
                "goal_pct": w_stats["goal_achievement_pct"],
                "met_count": w_stats["goal_met_count"],
                "record_count": w_stats["record_count"],
            }
        )

    return {
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "reference_date": today.isoformat(),
        "daily": {
            "date": today.isoformat(),
            "stats": _compute_period_stats(daily_records, goal_hours),
            "latest_session": latest_session,
        },
        "weekly": weekly,
        "monthly": monthly,
        "overall": {
            "stats": overall_stats,
            "consistency": overall_consistency,
            "date_range": {
                "earliest": dates[0] if dates else None,
                "latest": dates[-1] if dates else None,
                "span_days": span_days,
            },
        },
        "trend": {
            "status": trend_status,
            "detail": trend_detail,
            "weekly_delta_hours": delta,
        },
        "goal_progress_weekly": goal_progress_weekly,
        "insights": insights,
        "data_quality": {
            "total_records": len(records),
            "user_records": user_count,
            "demo_records": demo_count,
            "coverage_pct": coverage_pct,
            "has_demo_data": demo_count > 0,
        },
        "warnings": warnings,
        "methodology": {
            "duration": "Computed as exact elapsed minutes between complete (sleep_date, bedtime) and (wake_date, wake_time) timestamps.",
            "averages": "Arithmetic mean and median across recorded sessions; unlogged calendar days are omitted rather than zero-filled.",
            "consistency": "Derived from circular midnight-centered bedtime standard deviation and wake-time standard deviation.",
            "goal_completion": "Percentage of recorded sessions whose total duration meets or exceeds your configured sleep goal.",
        },
    }
