"""JSON stdin/stdout command dispatcher connecting Express API routes to real Python logic."""

from __future__ import annotations

import base64
import json
from pathlib import Path
import sys
from typing import Any

from .analytics import (
    compute_executive_summary,
    compute_monthly_analytics,
    compute_weekly_analytics,
)
from .plotting import generate_sleep_chart
from .reports import build_report_data, export_report_file
from .sleep_logic import calculate_duration
from .storage import (
    clear_all_records,
    delete_record,
    export_csv,
    export_json,
    import_csv,
    load_records,
    load_settings,
    reset_to_demo_data,
    save_record,
    save_settings,
    search_records,
    update_record,
)
from .validation import ValidationError


def _ensure_seeded() -> list[dict[str, Any]]:
    """Load records; seed realistic demo dataset automatically on very first cold start."""
    import config

    first_run = not config.RECORDS_JSON_PATH.exists() and not config.RECORDS_CSV_PATH.exists()
    if first_run:
        return reset_to_demo_data()
    loaded = load_records()
    assert isinstance(loaded, list)
    return loaded


def dispatch(action: str, payload: dict[str, Any]) -> dict[str, Any]:
    """Execute a backend operation and return a structured JSON-serializable result."""
    if action == "health":
        records = _ensure_seeded()
        return {"ok": True, "engine": "python", "version": sys.version.split()[0], "record_count": len(records)}

    if action == "list_records":
        _ensure_seeded()
        meta = load_records(include_meta=True)
        assert isinstance(meta, dict)
        sort_order = str(payload.get("sort_order", "newest"))
        if sort_order not in ("newest", "oldest", "longest", "shortest"):
            sort_order = "newest"
        result = search_records(
            keyword=str(payload.get("keyword", "")),
            date_query=str(payload.get("date_query", "")),
            start_date=str(payload.get("start_date", "")),
            end_date=str(payload.get("end_date", "")),
            min_hours=float(payload["min_hours"]) if payload.get("min_hours") not in (None, "") else None,
            max_hours=float(payload["max_hours"]) if payload.get("max_hours") not in (None, "") else None,
            sort_order=sort_order,
            page=int(payload.get("page", 1) or 1),
            page_size=int(payload.get("page_size", 0) or 0),
        )
        result["recovery_notice"] = meta.get("recovery_notice")
        return result

    if action == "preview_duration":
        calc = calculate_duration(
            str(payload.get("sleep_date", "")),
            str(payload.get("bedtime", "")),
            str(payload.get("wake_date", "")),
            str(payload.get("wake_time", "")),
        )
        return calc

    if action == "create_record":
        _ensure_seeded()
        record = save_record(payload)
        return {"record": record}

    if action == "update_record":
        _ensure_seeded()
        record_id = str(payload.get("id", ""))
        record = update_record(record_id, payload)
        return {"record": record}

    if action == "delete_record":
        _ensure_seeded()
        record_id = str(payload.get("id", ""))
        deleted = delete_record(record_id)
        return {"deleted": deleted}

    if action == "analytics_summary":
        records = _ensure_seeded()
        settings = load_settings()
        return compute_executive_summary(records, settings)

    if action == "analytics_weekly":
        records = _ensure_seeded()
        settings = load_settings()
        return compute_weekly_analytics(records, settings)

    if action == "analytics_monthly":
        records = _ensure_seeded()
        settings = load_settings()
        return compute_monthly_analytics(records, settings)

    if action == "get_settings":
        return {"settings": load_settings()}

    if action == "save_settings":
        saved = save_settings(payload)
        return {"settings": saved}

    if action == "reset_demo":
        records = reset_to_demo_data()
        return {"record_count": len(records), "records": records}

    if action == "clear_records":
        removed = clear_all_records()
        return {"removed_count": removed}

    if action == "import_csv":
        _ensure_seeded()
        csv_content = str(payload.get("csv_content", ""))
        preview_only = bool(payload.get("preview_only", False))
        return import_csv(csv_content, preview_only=preview_only)

    if action == "export_csv":
        records = _ensure_seeded()
        return {"filename": "sleepnova_records.csv", "mime": "text/csv; charset=utf-8", "content": export_csv(records)}

    if action == "export_json":
        records = _ensure_seeded()
        return {"filename": "sleepnova_records.json", "mime": "application/json; charset=utf-8", "content": export_json(records)}

    if action == "report_preview":
        records = _ensure_seeded()
        settings = load_settings()
        period = str(payload.get("period", "weekly"))
        return build_report_data(records, settings, period=period)

    if action == "export_report":
        records = _ensure_seeded()
        settings = load_settings()
        period = str(payload.get("period", "weekly"))
        fmt = str(payload.get("format", "markdown"))
        res = export_report_file(records, settings, period=period, export_format=fmt)
        if res.get("is_binary"):
            raw_bytes = Path(str(res["path"])).read_bytes()
            return {
                "filename": res["filename"],
                "mime": res["mime"],
                "is_binary": True,
                "base64": base64.b64encode(raw_bytes).decode("ascii"),
                "engine": res.get("engine"),
            }
        return {
            "filename": res["filename"],
            "mime": res["mime"],
            "is_binary": False,
            "content": res["content"],
        }

    if action == "generate_chart":
        records = _ensure_seeded()
        settings = load_settings()
        chart_kind = str(payload.get("chart_kind", "weekly_trend"))
        meta = generate_sleep_chart(records, settings, chart_kind=chart_kind)
        raw_bytes = Path(str(meta["path"])).read_bytes()
        return {
            "filename": meta["filename"],
            "mime": "image/png",
            "engine": meta["engine"],
            "chart_kind": meta["chart_kind"],
            "base64": base64.b64encode(raw_bytes).decode("ascii"),
        }

    raise ValueError(f"Unknown bridge action: {action}")


def main() -> None:
    try:
        raw_input = sys.stdin.read(2_500_000)
        req = json.loads(raw_input) if raw_input.strip() else {}
        action = str(req.get("action", ""))
        payload = req.get("payload") or {}
        data = dispatch(action, payload)
        sys.stdout.write(json.dumps({"ok": True, "data": data}, ensure_ascii=False))
    except ValidationError as exc:
        sys.stdout.write(
            json.dumps(
                {
                    "ok": False,
                    "status": 400,
                    "error": exc.message,
                    "field_errors": exc.field_errors,
                },
                ensure_ascii=False,
            )
        )
    except KeyError as exc:
        sys.stdout.write(
            json.dumps({"ok": False, "status": 404, "error": str(exc).strip("'")}, ensure_ascii=False)
        )
    except PermissionError:
        sys.stdout.write(
            json.dumps({"ok": False, "status": 500, "error": "Storage permission error."}, ensure_ascii=False)
        )
    except ValueError as exc:
        sys.stdout.write(
            json.dumps({"ok": False, "status": 400, "error": str(exc)}, ensure_ascii=False)
        )
    except Exception as exc:
        sys.stdout.write(
            json.dumps({"ok": False, "status": 500, "error": f"Internal backend error: {type(exc).__name__}"}, ensure_ascii=False)
        )


if __name__ == "__main__":
    main()
