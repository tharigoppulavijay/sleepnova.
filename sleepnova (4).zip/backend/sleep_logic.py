"""Core sleep calculation engine and domain data structures."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import uuid


@dataclass
class SleepRecord:
    """Structured representation of a single sleep session."""

    id: str
    sleep_date: str
    bedtime: str
    wake_date: str
    wake_time: str
    duration_minutes: int
    duration_hours: float
    notes: str = ""
    is_demo: bool = False
    created_at: str = ""
    updated_at: str = ""

    def to_dict(self) -> dict[str, object]:
        """Serialize record into a JSON/CSV-compatible dictionary."""
        return asdict(self)


def utc_now_iso() -> str:
    """Return current UTC timestamp in ISO-8601 format."""
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def generate_record_id(sleep_date: str) -> str:
    """Generate a unique, readable record identifier."""
    compact_date = sleep_date.replace("-", "")
    suffix = uuid.uuid4().hex[:6].upper()
    return f"SLP-{compact_date}-{suffix}"


def parse_sleep_datetimes(
    sleep_date: str,
    bedtime: str,
    wake_date: str,
    wake_time: str,
) -> tuple[datetime, datetime]:
    """Parse canonical YYYY-MM-DD and HH:MM strings into naive datetime objects."""
    start_dt = datetime.strptime(f"{sleep_date} {bedtime}", "%Y-%m-%d %H:%M")
    end_dt = datetime.strptime(f"{wake_date} {wake_time}", "%Y-%m-%d %H:%M")
    return start_dt, end_dt


def calculate_duration(
    sleep_date: str,
    bedtime: str,
    wake_date: str,
    wake_time: str,
) -> dict[str, object]:
    """
    Calculate sleep duration using complete date-time values.

    Supports overnight sessions crossing midnight and multi-day spans.
    Raises ValueError if end date-time is not strictly after start date-time.
    """
    start_dt, end_dt = parse_sleep_datetimes(sleep_date, bedtime, wake_date, wake_time)
    delta = end_dt - start_dt
    total_minutes = int(delta.total_seconds() // 60)

    if total_minutes <= 0:
        raise ValueError(
            "Wake-up date and time must be strictly after sleep start date and time."
        )

    hours_part, mins_part = divmod(total_minutes, 60)
    duration_hours = round(total_minutes / 60.0, 2)

    return {
        "duration_minutes": total_minutes,
        "duration_hours": duration_hours,
        "hours": hours_part,
        "minutes": mins_part,
        "formatted": format_duration(total_minutes),
        "crosses_midnight": wake_date != sleep_date,
    }


def format_duration(total_minutes: int) -> str:
    """Format integer minutes into human-readable 'Xh YYm' string."""
    if total_minutes < 0:
        total_minutes = 0
    hours, minutes = divmod(int(total_minutes), 60)
    return f"{hours}h {minutes:02d}m"


def compute_bedtime_offset_minutes(bedtime_hhmm: str) -> int:
    """
    Convert a 24-hour HH:MM bedtime into signed minutes relative to midnight (00:00).

    Times from 12:00 to 23:59 map to negative offsets (-720 to -1),
    while times from 00:00 to 11:59 map to non-negative offsets (0 to 719).
    This avoids the circular averaging bug where 23:30 and 00:30 average to 12:00.
    """
    hour_str, min_str = bedtime_hhmm.split(":")
    total = int(hour_str) * 60 + int(min_str)
    if total >= 12 * 60:
        return total - 24 * 60
    return total


def offset_minutes_to_hhmm(offset_minutes: float) -> str:
    """Convert signed midnight-relative minutes back into 24-hour HH:MM."""
    wrapped = round(offset_minutes) % (24 * 60)
    hours, minutes = divmod(wrapped, 60)
    return f"{hours:02d}:{minutes:02d}"


def time_to_minutes(hhmm: str) -> int:
    """Convert HH:MM to minutes since 00:00."""
    hour_str, min_str = hhmm.split(":")
    return int(hour_str) * 60 + int(min_str)


def minutes_to_hhmm(minutes_value: float) -> str:
    """Convert minutes since 00:00 into HH:MM."""
    wrapped = round(minutes_value) % (24 * 60)
    hours, mins = divmod(wrapped, 60)
    return f"{hours:02d}:{mins:02d}"


def create_record_object(
    sleep_date: str,
    bedtime: str,
    wake_date: str,
    wake_time: str,
    notes: str = "",
    record_id: str | None = None,
    is_demo: bool = False,
    created_at: str | None = None,
    updated_at: str | None = None,
) -> SleepRecord:
    """Construct a SleepRecord instance with computed duration and timestamps."""
    calc = calculate_duration(sleep_date, bedtime, wake_date, wake_time)
    now_iso = utc_now_iso()
    return SleepRecord(
        id=record_id or generate_record_id(sleep_date),
        sleep_date=sleep_date,
        bedtime=bedtime,
        wake_date=wake_date,
        wake_time=wake_time,
        duration_minutes=int(calc["duration_minutes"]),
        duration_hours=float(calc["duration_hours"]),
        notes=notes.strip(),
        is_demo=bool(is_demo),
        created_at=created_at or now_iso,
        updated_at=updated_at or now_iso,
    )
