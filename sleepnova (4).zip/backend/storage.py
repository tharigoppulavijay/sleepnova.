"""Local CSV & JSON data persistence engine with atomic writes and recovery."""

from __future__ import annotations

from contextlib import contextmanager
import csv
from datetime import datetime, timezone
import io
import json
import logging
import os
from pathlib import Path
import shutil
import tempfile
from typing import Any, Iterator

try:
    import fcntl
except ImportError:  # pragma: no cover - Windows fallback
    fcntl = None  # type: ignore[assignment]

import config
from .sleep_logic import create_record_object, utc_now_iso
from .validation import (
    ValidationError,
    sanitize_csv_cell,
    validate_record_id,
    validate_settings,
    validate_sleep_record_input,
)

logger = logging.getLogger("sleepnova.storage")
if not logger.handlers:
    config.ensure_directories()
    try:
        file_handler = logging.FileHandler(config.APP_LOG_PATH, encoding="utf-8")
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
        )
        logger.addHandler(file_handler)
    except OSError:
        pass
    logger.setLevel(logging.INFO)


def _atomic_write_text(target_path: Path, content: str) -> None:
    """Write text atomically via temporary file + os.replace to prevent partial writes."""
    target_path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(
        dir=str(target_path.parent),
        prefix=f".{target_path.name}.",
        suffix=".tmp",
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(content)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp_path, target_path)
    except Exception:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass
        raise


@contextmanager
def _storage_lock(target_dir: Path) -> Iterator[None]:
    """Serialize storage read-modify-write cycles across processes and threads."""
    target_dir.mkdir(parents=True, exist_ok=True)
    lock_path = target_dir / ".sleepnova.lock"
    if fcntl is None:
        yield
        return
    with lock_path.open("a+", encoding="utf-8") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def _normalize_loaded_record(raw: dict[str, Any]) -> dict[str, Any] | None:
    """Validate and normalize a stored record dictionary; returns None if malformed."""
    if not isinstance(raw, dict):
        return None
    try:
        record_id = validate_record_id(str(raw.get("id", "")))
        validated = validate_sleep_record_input(
            {
                "sleep_date": str(raw.get("sleep_date", "")),
                "bedtime": str(raw.get("bedtime", "")),
                "wake_date": str(raw.get("wake_date", "")),
                "wake_time": str(raw.get("wake_time", "")),
                "notes": str(raw.get("notes", "")),
                "is_demo": str(raw.get("is_demo", "false")).lower() == "true"
                if isinstance(raw.get("is_demo"), str)
                else bool(raw.get("is_demo", False)),
            },
            existing_records=None,
            allow_future=True,
        )
        rec = create_record_object(
            sleep_date=validated["sleep_date"],
            bedtime=validated["bedtime"],
            wake_date=validated["wake_date"],
            wake_time=validated["wake_time"],
            notes=validated["notes"],
            record_id=record_id,
            is_demo=bool(validated["is_demo"]),
            created_at=str(raw.get("created_at") or utc_now_iso()),
            updated_at=str(raw.get("updated_at") or utc_now_iso()),
        )
        return rec.to_dict()
    except (ValidationError, ValueError, KeyError, TypeError):
        return None


def _sync_storage_files(
    records: list[dict[str, Any]],
    json_path: Path | None = None,
    csv_path: Path | None = None,
) -> None:
    """
    Persist records to both JSON (primary source of truth) and CSV (synchronized mirror).

    Source-of-truth strategy:
    - `sleep_records.json` is the primary canonical store preserving exact types.
    - `sleep_records.csv` is synchronously updated on every write for universal portability
      and serves as an automatic recovery mirror if JSON is corrupted or missing.
    """
    j_path = json_path or config.RECORDS_JSON_PATH
    c_path = csv_path or config.RECORDS_CSV_PATH

    sorted_records = sorted(
        records,
        key=lambda r: (str(r.get("sleep_date", "")), str(r.get("bedtime", ""))),
        reverse=True,
    )

    json_payload = {
        "schema_version": 1,
        "updated_at": utc_now_iso(),
        "record_count": len(sorted_records),
        "records": sorted_records,
    }
    _atomic_write_text(j_path, json.dumps(json_payload, indent=2, ensure_ascii=False))

    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=config.CSV_HEADERS)
    writer.writeheader()
    for rec in sorted_records:
        writer.writerow(
            {
                "id": rec.get("id", ""),
                "sleep_date": rec.get("sleep_date", ""),
                "bedtime": rec.get("bedtime", ""),
                "wake_date": rec.get("wake_date", ""),
                "wake_time": rec.get("wake_time", ""),
                "duration_minutes": rec.get("duration_minutes", 0),
                "duration_hours": rec.get("duration_hours", 0.0),
                "notes": sanitize_csv_cell(str(rec.get("notes", ""))),
                "is_demo": bool(rec.get("is_demo", False)),
                "created_at": rec.get("created_at", ""),
                "updated_at": rec.get("updated_at", ""),
            }
        )
    _atomic_write_text(c_path, csv_buffer.getvalue())


def _read_csv_records(csv_path: Path) -> tuple[list[dict[str, Any]], int]:
    """Read and validate records from a CSV file, counting malformed rows skipped."""
    valid_records: list[dict[str, Any]] = []
    skipped = 0
    if not csv_path.exists():
        return valid_records, skipped

    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            return valid_records, skipped
        for row in reader:
            normalized = _normalize_loaded_record(row)
            if normalized:
                valid_records.append(normalized)
            else:
                skipped += 1
    return valid_records, skipped


def _load_records_unlocked(
    json_path: Path | None = None,
    csv_path: Path | None = None,
    include_meta: bool = False,
) -> list[dict[str, Any]] | dict[str, Any]:
    """Internal record loader assuming caller already holds _storage_lock."""
    config.ensure_directories()
    j_path = json_path or config.RECORDS_JSON_PATH
    c_path = csv_path or config.RECORDS_CSV_PATH

    recovery_notice: str | None = None
    malformed_skipped = 0
    records: list[dict[str, Any]] = []

    if not j_path.exists():
        if c_path.exists():
            try:
                records, malformed_skipped = _read_csv_records(c_path)
                _sync_storage_files(records, j_path, c_path)
                recovery_notice = (
                    f"Initialized missing JSON store from CSV mirror ({len(records)} records)."
                )
                logger.info(recovery_notice)
            except Exception as exc:
                logger.warning("Failed to recover from CSV mirror: %s", exc)
                _sync_storage_files([], j_path, c_path)
                recovery_notice = "Initialized clean empty sleep record files."
        else:
            _sync_storage_files([], j_path, c_path)
            recovery_notice = "Created initial sleep record storage templates."
            logger.info(recovery_notice)
    else:
        try:
            raw_text = j_path.read_text(encoding="utf-8")
            if not raw_text.strip():
                raise json.JSONDecodeError("Empty JSON file", raw_text, 0)
            parsed = json.loads(raw_text)
            if isinstance(parsed, dict) and isinstance(parsed.get("records"), list):
                raw_list = parsed["records"]
            elif isinstance(parsed, list):
                raw_list = parsed
            else:
                raise ValueError("Unexpected JSON top-level schema")

            seen_ids: set[str] = set()
            for item in raw_list:
                normalized = _normalize_loaded_record(item)
                if normalized and normalized["id"] not in seen_ids:
                    records.append(normalized)
                    seen_ids.add(str(normalized["id"]))
                else:
                    malformed_skipped += 1

            if malformed_skipped > 0:
                _sync_storage_files(records, j_path, c_path)
                recovery_notice = (
                    f"Skipped {malformed_skipped} malformed record(s) during validation."
                )
                logger.warning(recovery_notice)
            elif not c_path.exists():
                _sync_storage_files(records, j_path, c_path)

        except PermissionError as exc:
            logger.error("Permission denied reading %s: %s", j_path, exc)
            if c_path.exists():
                try:
                    records, malformed_skipped = _read_csv_records(c_path)
                    recovery_notice = (
                        f"JSON storage unreadable due to file permissions; loaded {len(records)} record(s) from CSV mirror."
                    )
                except OSError:
                    records = []
                    recovery_notice = "Storage files are unreadable due to file permissions."
            else:
                records = []
                recovery_notice = "Storage files are unreadable due to file permissions."

        except (json.JSONDecodeError, ValueError, OSError) as exc:
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            backup_path = j_path.with_name(f"{j_path.name}.corrupted.{stamp}")
            try:
                shutil.copy2(j_path, backup_path)
                logger.error("Corrupted JSON preserved at %s: %s", backup_path, exc)
            except OSError as copy_err:
                logger.error("Could not back up corrupted JSON: %s", copy_err)

            recovered: list[dict[str, Any]] = []
            if c_path.exists():
                try:
                    recovered, malformed_skipped = _read_csv_records(c_path)
                except Exception:
                    recovered = []

            records = recovered
            try:
                _sync_storage_files(records, j_path, c_path)
            except PermissionError:
                logger.error("Permission denied syncing recovered records to %s", j_path)
            if records:
                recovery_notice = (
                    f"Damaged JSON preserved at {backup_path.name}; "
                    f"recovered {len(records)} record(s) from CSV mirror."
                )
            else:
                recovery_notice = (
                    f"Damaged JSON preserved at {backup_path.name}; "
                    f"initialized clean storage template."
                )

    records.sort(
        key=lambda r: (str(r.get("sleep_date", "")), str(r.get("bedtime", ""))),
        reverse=True,
    )

    if include_meta:
        return {
            "records": records,
            "recovery_notice": recovery_notice,
            "malformed_skipped": malformed_skipped,
        }
    return records


def load_records(
    json_path: Path | None = None,
    csv_path: Path | None = None,
    include_meta: bool = False,
) -> list[dict[str, Any]] | dict[str, Any]:
    """
    Load sleep records with automatic missing-file initialization and corruption recovery.

    If `sleep_records.json` is corrupted:
    1. Preserves the damaged file as `sleep_records.json.corrupted.<timestamp>`.
    2. Attempts safe recovery from `sleep_records.csv` if present and valid.
    3. Otherwise creates a clean empty template and records recovery metadata.
    """
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        return _load_records_unlocked(
            json_path=json_path,
            csv_path=csv_path,
            include_meta=include_meta,
        )


def save_record(
    payload: dict[str, Any],
    json_path: Path | None = None,
    csv_path: Path | None = None,
    allow_future: bool = False,
) -> dict[str, Any]:
    """Validate and append a new sleep record, persisting to JSON and CSV."""
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        existing = _load_records_unlocked(json_path=json_path, csv_path=csv_path)
        assert isinstance(existing, list)

        validated = validate_sleep_record_input(
            payload, existing_records=existing, allow_future=allow_future
        )
        record = create_record_object(
            sleep_date=validated["sleep_date"],
            bedtime=validated["bedtime"],
            wake_date=validated["wake_date"],
            wake_time=validated["wake_time"],
            notes=validated["notes"],
            is_demo=bool(validated["is_demo"]),
        )
        record_dict = record.to_dict()
        existing.append(record_dict)
        _sync_storage_files(existing, json_path=json_path, csv_path=csv_path)
        logger.info("Saved record %s (%sh)", record.id, record.duration_hours)
        return record_dict


def update_record(
    record_id: str,
    payload: dict[str, Any],
    json_path: Path | None = None,
    csv_path: Path | None = None,
    allow_future: bool = False,
) -> dict[str, Any]:
    """Validate and update an existing sleep record by ID."""
    clean_id = validate_record_id(record_id)
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        existing = _load_records_unlocked(json_path=json_path, csv_path=csv_path)
        assert isinstance(existing, list)

        target_idx = next((i for i, r in enumerate(existing) if r.get("id") == clean_id), None)
        if target_idx is None:
            raise KeyError(f"Record '{clean_id}' was not found.")

        current = existing[target_idx]
        validated = validate_sleep_record_input(
            payload,
            existing_records=existing,
            exclude_id=clean_id,
            allow_future=allow_future,
        )
        updated_obj = create_record_object(
            sleep_date=validated["sleep_date"],
            bedtime=validated["bedtime"],
            wake_date=validated["wake_date"],
            wake_time=validated["wake_time"],
            notes=validated["notes"],
            record_id=clean_id,
            is_demo=bool(payload.get("is_demo", current.get("is_demo", False))),
            created_at=str(current.get("created_at") or utc_now_iso()),
            updated_at=utc_now_iso(),
        )
        updated_dict = updated_obj.to_dict()
        existing[target_idx] = updated_dict
        _sync_storage_files(existing, json_path=json_path, csv_path=csv_path)
        logger.info("Updated record %s", clean_id)
        return updated_dict


def delete_record(
    record_id: str,
    json_path: Path | None = None,
    csv_path: Path | None = None,
) -> dict[str, Any]:
    """Delete a sleep record by ID and synchronize JSON/CSV files."""
    clean_id = validate_record_id(record_id)
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        existing = _load_records_unlocked(json_path=json_path, csv_path=csv_path)
        assert isinstance(existing, list)

        target = next((r for r in existing if r.get("id") == clean_id), None)
        if target is None:
            raise KeyError(f"Record '{clean_id}' was not found.")

        remaining = [r for r in existing if r.get("id") != clean_id]
        _sync_storage_files(remaining, json_path=json_path, csv_path=csv_path)
        logger.info("Deleted record %s", clean_id)
        return target


def search_records(
    keyword: str = "",
    date_query: str = "",
    start_date: str = "",
    end_date: str = "",
    min_hours: float | None = None,
    max_hours: float | None = None,
    sort_order: str = "newest",
    page: int = 1,
    page_size: int = 0,
    json_path: Path | None = None,
    csv_path: Path | None = None,
) -> dict[str, Any]:
    """
    Filter, search, sort, and optionally paginate sleep records on the backend.
    """
    records = load_records(json_path=json_path, csv_path=csv_path)
    assert isinstance(records, list)

    kw = keyword.strip().lower()
    dq = date_query.strip()
    s_date = start_date.strip()
    e_date = end_date.strip()

    filtered: list[dict[str, Any]] = []
    for rec in records:
        if kw:
            haystack = " ".join(
                [
                    str(rec.get("id", "")),
                    str(rec.get("sleep_date", "")),
                    str(rec.get("wake_date", "")),
                    str(rec.get("notes", "")),
                ]
            ).lower()
            if kw not in haystack:
                continue

        if dq and dq not in str(rec.get("sleep_date", "")) and dq not in str(rec.get("wake_date", "")):
            continue

        rec_date = str(rec.get("sleep_date", ""))
        if s_date and rec_date < s_date:
            continue
        if e_date and rec_date > e_date:
            continue

        hours = float(rec.get("duration_hours", 0.0))
        if min_hours is not None and hours < float(min_hours):
            continue
        if max_hours is not None and hours > float(max_hours):
            continue

        filtered.append(rec)

    reverse = sort_order != "oldest"
    if sort_order == "longest":
        filtered.sort(key=lambda r: float(r.get("duration_hours", 0.0)), reverse=True)
    elif sort_order == "shortest":
        filtered.sort(key=lambda r: float(r.get("duration_hours", 0.0)), reverse=False)
    else:
        filtered.sort(
            key=lambda r: (str(r.get("sleep_date", "")), str(r.get("bedtime", ""))),
            reverse=reverse,
        )

    total_count = len(filtered)
    if page_size and page_size > 0:
        safe_page = max(1, int(page))
        total_pages = max(1, (total_count + page_size - 1) // page_size)
        safe_page = min(safe_page, total_pages)
        start_idx = (safe_page - 1) * page_size
        items = filtered[start_idx : start_idx + page_size]
    else:
        safe_page = 1
        total_pages = 1
        items = filtered

    return {
        "records": items,
        "total": total_count,
        "page": safe_page,
        "page_size": page_size or total_count,
        "total_pages": total_pages,
    }


def export_csv(
    records: list[dict[str, Any]] | None = None,
    output_path: Path | None = None,
) -> str:
    """Serialize sleep records to CSV string and optionally write to disk."""
    data = records if records is not None else load_records()
    assert isinstance(data, list)

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=config.CSV_HEADERS)
    writer.writeheader()
    for rec in data:
        writer.writerow(
            {
                "id": rec.get("id", ""),
                "sleep_date": rec.get("sleep_date", ""),
                "bedtime": rec.get("bedtime", ""),
                "wake_date": rec.get("wake_date", ""),
                "wake_time": rec.get("wake_time", ""),
                "duration_minutes": rec.get("duration_minutes", 0),
                "duration_hours": rec.get("duration_hours", 0.0),
                "notes": sanitize_csv_cell(str(rec.get("notes", ""))),
                "is_demo": bool(rec.get("is_demo", False)),
                "created_at": rec.get("created_at", ""),
                "updated_at": rec.get("updated_at", ""),
            }
        )
    content = buf.getvalue()
    if output_path is not None:
        _atomic_write_text(output_path, content)
    return content


def export_json(
    records: list[dict[str, Any]] | None = None,
    output_path: Path | None = None,
) -> str:
    """Serialize sleep records to formatted JSON string and optionally write to disk."""
    data = records if records is not None else load_records()
    assert isinstance(data, list)

    payload = {
        "application": config.APP_NAME,
        "exported_at": utc_now_iso(),
        "record_count": len(data),
        "records": data,
    }
    content = json.dumps(payload, indent=2, ensure_ascii=False)
    if output_path is not None:
        _atomic_write_text(output_path, content)
    return content


def import_csv(
    csv_source: str | Path,
    json_path: Path | None = None,
    csv_path: Path | None = None,
    allow_future: bool = False,
    preview_only: bool = False,
) -> dict[str, Any]:
    """
    Bulk-import legacy or external CSV datasets with row-by-row validation.

    Required columns: sleep_date, bedtime, wake_date, wake_time (notes optional).
    Rejects malformed or duplicate rows individually without damaging existing data.
    When preview_only=True, validates and classifies rows without mutating disk files.
    """
    if isinstance(csv_source, Path) or (
        isinstance(csv_source, str) and "\n" not in csv_source and Path(csv_source).exists()
    ):
        source_text = Path(csv_source).read_text(encoding="utf-8")
    else:
        source_text = str(csv_source)

    if not source_text.strip():
        raise ValidationError("Uploaded CSV file is empty.")

    if len(source_text.encode("utf-8")) > 2 * 1024 * 1024:
        raise ValidationError("CSV import exceeds the 2 MB maximum upload limit.")

    reader = csv.DictReader(io.StringIO(source_text))
    if not reader.fieldnames:
        raise ValidationError("CSV header row is missing or unreadable.")

    normalized_headers = {h.strip().lower(): h for h in reader.fieldnames if h}
    required_cols = {"sleep_date", "bedtime", "wake_date", "wake_time"}
    missing_cols = sorted(required_cols - set(normalized_headers.keys()))
    if missing_cols:
        raise ValidationError(
            f"CSV is missing required column(s): {', '.join(missing_cols)}. "
            f"Expected headers: sleep_date, bedtime, wake_date, wake_time (optional: notes)."
        )

    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        existing = _load_records_unlocked(json_path=json_path, csv_path=csv_path)
        assert isinstance(existing, list)
        working_records = list(existing)

        imported_records: list[dict[str, Any]] = []
        error_logs: list[dict[str, Any]] = []
        duplicate_count = 0
        invalid_count = 0
        total_rows = 0

        try:
            for row_num, raw_row in enumerate(reader, start=2):
                total_rows += 1
                mapped = {
                    k.strip().lower(): (v.strip() if isinstance(v, str) else "")
                    for k, v in raw_row.items()
                    if k is not None
                }
                try:
                    validated = validate_sleep_record_input(
                        {
                            "sleep_date": mapped.get("sleep_date", ""),
                            "bedtime": mapped.get("bedtime", ""),
                            "wake_date": mapped.get("wake_date", ""),
                            "wake_time": mapped.get("wake_time", ""),
                            "notes": mapped.get("notes", ""),
                            "is_demo": mapped.get("is_demo", "false").lower() == "true",
                        },
                        existing_records=working_records,
                        allow_future=allow_future,
                    )

                    candidate_id = mapped.get("id") or None
                    if candidate_id:
                        candidate_id = validate_record_id(candidate_id)
                        if any(r.get("id") == candidate_id for r in working_records):
                            candidate_id = None

                    rec = create_record_object(
                        sleep_date=validated["sleep_date"],
                        bedtime=validated["bedtime"],
                        wake_date=validated["wake_date"],
                        wake_time=validated["wake_time"],
                        notes=validated["notes"],
                        record_id=candidate_id,
                        is_demo=bool(validated["is_demo"]),
                    ).to_dict()
                    working_records.append(rec)
                    imported_records.append(rec)
                except ValidationError as exc:
                    is_dup = "duplicate" in exc.message.lower() or "overlapping" in exc.message.lower()
                    if is_dup:
                        duplicate_count += 1
                    else:
                        invalid_count += 1
                    error_logs.append(
                        {
                            "row": row_num,
                            "category": "duplicate" if is_dup else "invalid",
                            "raw": {
                                "sleep_date": mapped.get("sleep_date", ""),
                                "bedtime": mapped.get("bedtime", ""),
                                "wake_date": mapped.get("wake_date", ""),
                                "wake_time": mapped.get("wake_time", ""),
                            },
                            "error": exc.message,
                        }
                    )
                except Exception as exc:
                    invalid_count += 1
                    error_logs.append(
                        {
                            "row": row_num,
                            "category": "invalid",
                            "raw": mapped,
                            "error": f"Unexpected row format: {exc}",
                        }
                    )
        except csv.Error as exc:
            raise ValidationError(f"Malformed CSV formatting: {exc}") from exc

        if imported_records and not preview_only:
            _sync_storage_files(working_records, json_path=json_path, csv_path=csv_path)
            logger.info(
                "Bulk CSV import: %d imported, %d invalid, %d duplicates out of %d rows",
                len(imported_records),
                invalid_count,
                duplicate_count,
                total_rows,
            )

    return {
        "preview_only": preview_only,
        "total_rows": total_rows,
        "imported_count": len(imported_records),
        "rejected_count": len(error_logs),
        "invalid_count": invalid_count,
        "duplicate_count": duplicate_count,
        "imported_records": imported_records,
        "error_logs": error_logs,
    }


def load_settings(settings_path: Path | None = None) -> dict[str, Any]:
    """Load persistent application settings with safe fallback to defaults."""
    config.ensure_directories()
    s_path = settings_path or config.SETTINGS_JSON_PATH
    if not s_path.exists():
        defaults = dict(config.DEFAULT_SETTINGS)
        _atomic_write_text(s_path, json.dumps(defaults, indent=2))
        return defaults
    try:
        raw = json.loads(s_path.read_text(encoding="utf-8"))
        return validate_settings(raw)
    except Exception as exc:
        logger.warning("Corrupted or invalid settings.json (%s); restoring defaults.", exc)
        defaults = dict(config.DEFAULT_SETTINGS)
        _atomic_write_text(s_path, json.dumps(defaults, indent=2))
        return defaults


def save_settings(
    payload: dict[str, Any],
    settings_path: Path | None = None,
) -> dict[str, Any]:
    """Validate and save application settings locally."""
    s_path = settings_path or config.SETTINGS_JSON_PATH
    validated = validate_settings(payload)
    with _storage_lock(s_path.parent):
        _atomic_write_text(s_path, json.dumps(validated, indent=2))
    logger.info("Updated application settings")
    return validated


def clear_all_records(
    json_path: Path | None = None,
    csv_path: Path | None = None,
) -> int:
    """Clear all stored records safely, returning number of records removed."""
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        existing = _load_records_unlocked(json_path=json_path, csv_path=csv_path)
        assert isinstance(existing, list)
        count = len(existing)
        _sync_storage_files([], json_path=json_path, csv_path=csv_path)
    logger.info("Cleared all %d sleep records", count)
    return count


def build_demo_dataset() -> list[dict[str, Any]]:
    """
    Generate 38 realistic, internally consistent demonstration sleep records
    spanning the past 40 days relative to today, including normal nights,
    overnight midnight crossings, weekend shifts, and boundary cases.
    """
    from datetime import date, timedelta

    today = date.today()
    # Pattern offsets across 38 days: (days_ago, bedtime_hhmm, duration_mins, note)
    # Bedtimes >= 18:00 start on (today - days_ago - 1); bedtimes < 06:00 start on (today - days_ago)
    patterns: list[tuple[int, str, int, str]] = [
        (39, "22:45", 475, "Demonstration data: steady weeknight routine"),
        (38, "23:10", 450, "Demonstration data: late study review"),
        (37, "22:30", 495, "Demonstration data: rested wake-up"),
        (36, "23:45", 420, "Demonstration data: midnight transition"),
        (35, "00:25", 435, "Demonstration data: post-midnight bedtime"),
        (34, "23:55", 530, "Demonstration data: weekend recovery sleep"),
        (33, "22:50", 480, "Demonstration data: Sunday reset"),
        (32, "22:20", 490, "Demonstration data: consistent 8h+ night"),
        (31, "23:05", 455, "Demonstration data: normal weekday"),
        (30, "23:30", 430, "Demonstration data: reading before sleep"),
        (29, "01:15", 330, "Demonstration data: short boundary session (5h 30m)"),
        (28, "22:15", 525, "Demonstration data: early bedtime recovery"),
        (27, "23:40", 510, "Demonstration data: Saturday morning sleep-in"),
        (26, "22:40", 480, "Demonstration data: balanced 8h target"),
        (25, "22:55", 465, "Demonstration data: steady routine"),
        (24, "23:15", 445, "Demonstration data: normal evening"),
        (23, "22:35", 495, "Demonstration data: quiet night"),
        (22, "00:10", 415, "Demonstration data: post-midnight start"),
        (21, "21:45", 645, "Demonstration data: long recovery session (10h 45m)"),
        (20, "23:00", 480, "Demonstration data: weekend wind-down"),
        (19, "22:30", 480, "Demonstration data: exact 8h00m benchmark"),
        (18, "22:50", 460, "Demonstration data: normal weekday"),
        (17, "23:25", 435, "Demonstration data: evening lab prep"),
        (16, "01:40", 285, "Demonstration data: short boundary night (4h 45m)"),
        (15, "22:25", 505, "Demonstration data: early recovery night"),
        (14, "23:50", 520, "Demonstration data: weekend schedule"),
        (13, "22:45", 485, "Demonstration data: Sunday evening"),
        (12, "22:30", 480, "Demonstration data: steady weekday"),
        (11, "22:50", 470, "Demonstration data: consistent bedtime"),
        (10, "23:10", 455, "Demonstration data: moderate schedule"),
        (9, "22:40", 490, "Demonstration data: uninterrupted rest"),
        (8, "00:35", 440, "Demonstration data: Friday late night"),
        (7, "23:20", 515, "Demonstration data: Saturday rest"),
        (6, "22:35", 490, "Demonstration data: Sunday calm routine"),
        (5, "22:45", 475, "Demonstration data: Monday target met"),
        (4, "23:00", 465, "Demonstration data: Tuesday normal"),
        (3, "22:20", 500, "Demonstration data: Wednesday refreshed"),
        (2, "23:15", 445, "Demonstration data: Thursday study session"),
        (1, "22:40", 485, "Demonstration data: Friday morning wake"),
    ]

    records: list[dict[str, Any]] = []
    for idx, (days_ago, bedtime_str, duration_mins, note) in enumerate(patterns, start=1):
        wake_base = today - timedelta(days=days_ago)
        bed_hour, bed_min = map(int, bedtime_str.split(":"))
        if bed_hour >= 12:
            sleep_date_obj = wake_base - timedelta(days=1)
        else:
            sleep_date_obj = wake_base

        start_dt = datetime(
            sleep_date_obj.year, sleep_date_obj.month, sleep_date_obj.day, bed_hour, bed_min
        )
        end_dt = start_dt + timedelta(minutes=duration_mins)

        rec = create_record_object(
            sleep_date=start_dt.strftime("%Y-%m-%d"),
            bedtime=start_dt.strftime("%H:%M"),
            wake_date=end_dt.strftime("%Y-%m-%d"),
            wake_time=end_dt.strftime("%H:%M"),
            notes=note,
            record_id=f"SLP-DEMO-{idx:03d}",
            is_demo=True,
        )
        records.append(rec.to_dict())

    return records


def reset_to_demo_data(
    json_path: Path | None = None,
    csv_path: Path | None = None,
) -> list[dict[str, Any]]:
    """Seed or reset local storage with the 39-record demonstration dataset."""
    demo_records = build_demo_dataset()
    j_path = json_path or config.RECORDS_JSON_PATH
    with _storage_lock(j_path.parent):
        _sync_storage_files(demo_records, json_path=json_path, csv_path=csv_path)
    logger.info("Reset storage to %d demonstration records", len(demo_records))
    return demo_records
