# SleepNova — Complete Historical Sleep Report

- **Reporting Period:** 2026-10-15 to 2026-11-22
- **Generated At:** 2026-11-24 09:50:16
- **Records Included:** 39

## Executive Metrics

| Metric | Value |
| --- | --- |
| Total Recorded Sleep | 305h 30m (305.5 hrs) |
| Average Sleep Duration | 7h 50m (7.83 hrs) |
| Longest Session | 10h 45m (2026-11-02) |
| Shortest Session | 4h 45m (2026-11-08) |
| Configured Goal | 8.0 hrs (20/39 sessions met · 51.3%) |

## Schedule Consistency

- **Consistency Index:** 71% (Moderately Consistent)
- **Average Bedtime:** 23:09 (σ = 49.2 min)
- **Average Wake Time:** 06:59 (σ = 36.8 min)
- **Method:** Calculated from the standard deviation of midnight-centered bedtime offsets and wake-up clock times across stored records. Higher values indicate smaller day-to-day schedule drift; this is a statistical indicator, not a medical assessment.

## Weekly & Monthly Trends

- **Weekly Trends (2026-11-18 to 2026-11-24):** 6 session(s) averaging 7h 57m (+0.01h vs prior 7d); goal attainment 50.0%.
- **Monthly Trends (2026-10-26 to 2026-11-24):** 29 session(s) averaging 7h 51m (+0.09h vs prior 30d); goal attainment 55.2%.

## Trend & Data Quality

- **Trend Summary:** Average sleep duration remained steady (+0.01h) compared to the previous 7 days.
- **Data Composition:** 0 personal record(s), 39 demonstration record(s).

## Threshold Indicators

- **[NOMINAL] All routine thresholds within configured range**: Recent entries stay within 5.5h–10.5h and bedtime variation is within 60 minutes.

## Session Log

| ID | Sleep Date | Bedtime | Wake Date | Wake Time | Duration | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| SLP-DEMO-039 | 2026-11-22 | 22:40 | 2026-11-23 | 06:45 | 8h 05m | Demonstration data: Friday morning wake |
| SLP-DEMO-038 | 2026-11-21 | 23:15 | 2026-11-22 | 06:40 | 7h 25m | Demonstration data: Thursday study session |
| SLP-DEMO-037 | 2026-11-20 | 22:20 | 2026-11-21 | 06:40 | 8h 20m | Demonstration data: Wednesday refreshed |
| SLP-DEMO-036 | 2026-11-19 | 23:00 | 2026-11-20 | 06:45 | 7h 45m | Demonstration data: Tuesday normal |
| SLP-DEMO-035 | 2026-11-18 | 22:45 | 2026-11-19 | 06:40 | 7h 55m | Demonstration data: Monday target met |
| SLP-DEMO-034 | 2026-11-17 | 22:35 | 2026-11-18 | 06:45 | 8h 10m | Demonstration data: Sunday calm routine |
| SLP-DEMO-033 | 2026-11-16 | 23:20 | 2026-11-17 | 07:55 | 8h 35m | Demonstration data: Saturday rest |
| SLP-DEMO-032 | 2026-11-16 | 00:35 | 2026-11-16 | 07:55 | 7h 20m | Demonstration data: Friday late night |
| SLP-DEMO-031 | 2026-11-14 | 22:40 | 2026-11-15 | 06:50 | 8h 10m | Demonstration data: uninterrupted rest |
| SLP-DEMO-030 | 2026-11-13 | 23:10 | 2026-11-14 | 06:45 | 7h 35m | Demonstration data: moderate schedule |
| SLP-DEMO-029 | 2026-11-12 | 22:50 | 2026-11-13 | 06:40 | 7h 50m | Demonstration data: consistent bedtime |
| SLP-DEMO-028 | 2026-11-11 | 22:30 | 2026-11-12 | 06:30 | 8h 00m | Demonstration data: steady weekday |
| SLP-DEMO-027 | 2026-11-10 | 22:45 | 2026-11-11 | 06:50 | 8h 05m | Demonstration data: Sunday evening |
| SLP-DEMO-026 | 2026-11-09 | 23:50 | 2026-11-10 | 08:30 | 8h 40m | Demonstration data: weekend schedule |
| SLP-DEMO-025 | 2026-11-08 | 22:25 | 2026-11-09 | 06:50 | 8h 25m | Demonstration data: early recovery night |
| SLP-DEMO-024 | 2026-11-08 | 01:40 | 2026-11-08 | 06:25 | 4h 45m | Demonstration data: short boundary night (4h 45m) |
| SLP-DEMO-023 | 2026-11-06 | 23:25 | 2026-11-07 | 06:40 | 7h 15m | Demonstration data: evening lab prep |
| SLP-DEMO-022 | 2026-11-05 | 22:50 | 2026-11-06 | 06:30 | 7h 40m | Demonstration data: normal weekday |
| SLP-DEMO-021 | 2026-11-04 | 22:30 | 2026-11-05 | 06:30 | 8h 00m | Demonstration data: exact 8h00m benchmark |
| SLP-DEMO-020 | 2026-11-03 | 23:00 | 2026-11-04 | 07:00 | 8h 00m | Demonstration data: weekend wind-down |
| SLP-DEMO-019 | 2026-11-02 | 21:45 | 2026-11-03 | 08:30 | 10h 45m | Demonstration data: long recovery session (10h 45m) |
| SLP-DEMO-018 | 2026-11-02 | 00:10 | 2026-11-02 | 07:05 | 6h 55m | Demonstration data: post-midnight start |
| SLP-DEMO-017 | 2026-10-31 | 22:35 | 2026-11-01 | 06:50 | 8h 15m | Demonstration data: quiet night |
| SLP-DEMO-016 | 2026-10-30 | 23:15 | 2026-10-31 | 06:40 | 7h 25m | Demonstration data: normal evening |
| SLP-DEMO-015 | 2026-10-29 | 22:55 | 2026-10-30 | 06:40 | 7h 45m | Demonstration data: steady routine |
| SLP-DEMO-014 | 2026-10-28 | 22:40 | 2026-10-29 | 06:40 | 8h 00m | Demonstration data: balanced 8h target |
| SLP-DEMO-013 | 2026-10-27 | 23:40 | 2026-10-28 | 08:10 | 8h 30m | Demonstration data: Saturday morning sleep-in |
| SLP-DEMO-012 | 2026-10-26 | 22:15 | 2026-10-27 | 07:00 | 8h 45m | Demonstration data: early bedtime recovery |
| SLP-DEMO-011 | 2026-10-26 | 01:15 | 2026-10-26 | 06:45 | 5h 30m | Demonstration data: short boundary session (5h 30m) |
| SLP-DEMO-010 | 2026-10-24 | 23:30 | 2026-10-25 | 06:40 | 7h 10m | Demonstration data: reading before sleep |
| SLP-DEMO-009 | 2026-10-23 | 23:05 | 2026-10-24 | 06:40 | 7h 35m | Demonstration data: normal weekday |
| SLP-DEMO-008 | 2026-10-22 | 22:20 | 2026-10-23 | 06:30 | 8h 10m | Demonstration data: consistent 8h+ night |
| SLP-DEMO-007 | 2026-10-21 | 22:50 | 2026-10-22 | 06:50 | 8h 00m | Demonstration data: Sunday reset |
| SLP-DEMO-006 | 2026-10-20 | 23:55 | 2026-10-21 | 08:45 | 8h 50m | Demonstration data: weekend recovery sleep |
| SLP-DEMO-005 | 2026-10-20 | 00:25 | 2026-10-20 | 07:40 | 7h 15m | Demonstration data: post-midnight bedtime |
| SLP-DEMO-004 | 2026-10-18 | 23:45 | 2026-10-19 | 06:45 | 7h 00m | Demonstration data: midnight transition |
| SLP-DEMO-003 | 2026-10-17 | 22:30 | 2026-10-18 | 06:45 | 8h 15m | Demonstration data: rested wake-up |
| SLP-DEMO-002 | 2026-10-16 | 23:10 | 2026-10-17 | 06:40 | 7h 30m | Demonstration data: late study review |
| SLP-DEMO-001 | 2026-10-15 | 22:45 | 2026-10-16 | 06:40 | 7h 55m | Demonstration data: steady weeknight routine |
