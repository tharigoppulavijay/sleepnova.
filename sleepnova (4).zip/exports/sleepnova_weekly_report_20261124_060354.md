# SleepNova — Weekly Sleep Report

- **Reporting Period:** 2026-11-18 to 2026-11-24
- **Generated At:** 2026-11-24 06:03:54
- **Records Included:** 6

## Executive Metrics

| Metric | Value |
| --- | --- |
| Total Recorded Sleep | 47h 40m (47.67 hrs) |
| Average Sleep Duration | 7h 57m (7.95 hrs) |
| Longest Session | 8h 20m (2026-11-20) |
| Shortest Session | 7h 25m (2026-11-21) |
| Configured Goal | 8.0 hrs (3/6 sessions met · 50.0%) |

## Schedule Consistency

- **Consistency Index:** 93% (Highly Consistent)
- **Average Bedtime:** 22:46 (σ = 19.3 min)
- **Average Wake Time:** 06:42 (σ = 2.7 min)
- **Method:** Calculated from the standard deviation of midnight-centered bedtime offsets and wake-up clock times across stored records. Higher values indicate smaller day-to-day schedule drift; this is a statistical indicator, not a medical assessment.

## Trend & Data Quality

- **Trend Summary:** Average sleep duration remained steady (+0.01h) compared to the previous 7 days.
- **Data Composition:** 0 personal record(s), 6 demonstration record(s).

## Threshold Indicators

- **[NOMINAL] All routine thresholds within configured range**: Recent entries stay within 5.5h–10.5h and bedtime variation is within 60 minutes.

## Session Log

| ID | Sleep Date | Bedtime | Wake Date | Wake Time | Duration | Notes |
| --- | --- | --- | --- | --- | --- | --- |
| SLP-DEMO-039 | 2026-11-22 | 22:40 | 2026-11-23 | 06:45 | 8h 05m | Demonstration data: Friday morning wake |
| SLP-DEMO-038 | 2026-11-21 | 23:15 | 2026-11-22 | 06:40 | 7h 25m | Demonstration data: Thursday study session |
| SLP-DEMO-037 | 2026-11-20 | 22:20 | 2026-11-21 | 06:40 | 8h 20m | Demonstration data: Wednesday refreshed |
| SLP-DEMO-036 | 2026-11-19 | 23:00 | 2026-11-20 | 06:45 | 7h 45m | Demonstration data: Tuesday normal |
| SLP-DEMO-035 | 2026-11-18 | 22:45 | 2026-11-19 | 06:40 | 7h 55m | Demonstration data: Monday target met |
| SLP-DEMO-034 | 2026-11-17 | 22:35 | 2026-11-18 | 06:45 | 8h 10m | Demonstration data: Sunday calm routine |
