import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import express, { type NextFunction, type Request, type Response } from 'express';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';

interface BridgeResponse<T = Record<string, unknown>> {
  ok: boolean;
  status?: number;
  error?: string;
  field_errors?: Record<string, string>;
  data?: T;
}

function callPythonBackend<T = Record<string, unknown>>(
  action: string,
  payload: Record<string, unknown> = {},
): Promise<BridgeResponse<T>> {
  return new Promise((resolve, reject) => {
    const child = spawn('python3', ['-m', 'backend.bridge'], {
      cwd: __dirname,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, PYTHONUNBUFFERED: '1' },
    });

    let stdout = '';
    let stderr = '';
    let settled = false;

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true;
        child.kill('SIGKILL');
        reject(new Error('Python backend execution timed out.'));
      }
    }, 15_000);

    child.stdout.on('data', (chunk: Buffer) => {
      stdout += chunk.toString('utf-8');
    });
    child.stderr.on('data', (chunk: Buffer) => {
      stderr += chunk.toString('utf-8');
    });
    child.on('error', (err) => {
      clearTimeout(timer);
      if (!settled) {
        settled = true;
        reject(err);
      }
    });
    child.on('close', (code) => {
      clearTimeout(timer);
      if (settled) return;
      settled = true;
      if (!stdout.trim()) {
        reject(new Error(`Python backend exited with code ${code}: ${stderr}`));
        return;
      }
      try {
        const parsed = JSON.parse(stdout) as BridgeResponse<T>;
        resolve(parsed);
      } catch (err) {
        reject(new Error(`Invalid JSON from Python backend: ${String(err)}`));
      }
    });

    child.stdin.write(JSON.stringify({ action, payload }));
    child.stdin.end();
  });
}

function verifySameOriginOrHeader(req: Request, res: Response, next: NextFunction): void {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    next();
    return;
  }
  const host = req.get('X-Forwarded-Host') || req.get('Host');
  const origin = req.get('Origin');
  if (origin) {
    if (!host) {
      res.status(403).json({ ok: false, error: 'Request origin verification failed.' });
      return;
    }
    try {
      const originHost = new URL(origin).host;
      if (originHost !== host) {
        res.status(403).json({ ok: false, error: 'Cross-origin mutation rejected.' });
        return;
      }
      next();
      return;
    } catch {
      res.status(403).json({ ok: false, error: 'Invalid request origin.' });
      return;
    }
  }
  const customHeader = req.get('X-Requested-With');
  if (customHeader === 'SleepNova-Client') {
    next();
    return;
  }
  const referer = req.get('Referer');
  if (referer && host) {
    try {
      if (new URL(referer).host === host) {
        next();
        return;
      }
    } catch {
      // fall through to 403
    }
  }
  res.status(403).json({ ok: false, error: 'Request origin verification failed.' });
}

function securityHeaders(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
}

const ALLOWED_SORTS = new Set(['newest', 'oldest', 'longest', 'shortest']);
const ALLOWED_PERIODS = new Set(['daily', 'weekly', 'monthly', 'all']);
const ALLOWED_FORMATS = new Set(['csv', 'json', 'markdown', 'txt', 'text', 'audit', 'png']);

async function startServer(): Promise<void> {
  const app = express();
  app.use(securityHeaders);
  app.use(express.json({ limit: '2mb' }));
  app.use((err: Error & { status?: number; type?: string }, _req: Request, res: Response, next: NextFunction) => {
    if (err?.type === 'entity.too.large') {
      res.status(413).json({ ok: false, error: 'Request payload exceeds the 2 MB limit.' });
      return;
    }
    if (err instanceof SyntaxError && err.status === 400) {
      res.status(400).json({ ok: false, error: 'Malformed JSON request body.' });
      return;
    }
    next(err);
  });
  app.use('/api', verifySameOriginOrHeader);

  app.get('/api/health', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('health');
      if (!result.ok) {
        res.status(result.status || 500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Python engine unavailable.' });
    }
  });

  app.get('/api/records', async (req: Request, res: Response) => {
    const sortOrder = String(req.query.sort || 'newest');
    if (!ALLOWED_SORTS.has(sortOrder)) {
      res.status(400).json({ ok: false, error: 'Unsupported sort order.' });
      return;
    }
    try {
      const result = await callPythonBackend('list_records', {
        keyword: String(req.query.keyword || ''),
        date_query: String(req.query.date || ''),
        start_date: String(req.query.start_date || ''),
        end_date: String(req.query.end_date || ''),
        min_hours: req.query.min_hours ? String(req.query.min_hours) : '',
        max_hours: req.query.max_hours ? String(req.query.max_hours) : '',
        sort_order: sortOrder,
        page: Number(req.query.page || 1),
        page_size: Number(req.query.page_size || 0),
      });
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to load sleep records.' });
    }
  });

  app.post('/api/records/preview', async (req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('preview_duration', req.body || {});
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to calculate duration.' });
    }
  });

  app.post('/api/records', async (req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('create_record', req.body || {});
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.status(201).json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to save sleep record.' });
    }
  });

  const recordIdRe = /^[A-Za-z0-9_-]{3,40}$/;

  app.put('/api/records/:id', async (req: Request, res: Response) => {
    const id = String(req.params.id || '');
    if (!recordIdRe.test(id)) {
      res.status(400).json({ ok: false, error: 'Invalid record ID format.' });
      return;
    }
    try {
      const result = await callPythonBackend('update_record', {
        ...(req.body || {}),
        id,
      });
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to update sleep record.' });
    }
  });

  app.delete('/api/records/:id', async (req: Request, res: Response) => {
    const id = String(req.params.id || '');
    if (!recordIdRe.test(id)) {
      res.status(400).json({ ok: false, error: 'Invalid record ID format.' });
      return;
    }
    try {
      const result = await callPythonBackend('delete_record', { id });
      if (!result.ok) {
        res.status(result.status || 404).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to delete sleep record.' });
    }
  });

  app.get('/api/analytics/summary', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('analytics_summary');
      if (!result.ok) {
        res.status(result.status || 500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to compute executive summary.' });
    }
  });

  app.get('/api/analytics/weekly', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('analytics_weekly');
      if (!result.ok) {
        res.status(result.status || 500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to compute weekly analytics.' });
    }
  });

  app.get('/api/analytics/monthly', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('analytics_monthly');
      if (!result.ok) {
        res.status(result.status || 500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to compute monthly analytics.' });
    }
  });

  app.get('/api/export/csv', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend<{ filename: string; mime: string; content: string }>('export_csv');
      if (!result.ok || !result.data) {
        res.status(500).json({ ok: false, error: 'Export failed.' });
        return;
      }
      res.setHeader('Content-Type', result.data.mime);
      res.setHeader('Content-Disposition', `attachment; filename="${result.data.filename}"`);
      res.send(result.data.content);
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to export CSV.' });
    }
  });

  app.get('/api/export/json', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend<{ filename: string; mime: string; content: string }>('export_json');
      if (!result.ok || !result.data) {
        res.status(500).json({ ok: false, error: 'Export failed.' });
        return;
      }
      res.setHeader('Content-Type', result.data.mime);
      res.setHeader('Content-Disposition', `attachment; filename="${result.data.filename}"`);
      res.send(result.data.content);
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to export JSON.' });
    }
  });

  app.get('/api/reports/preview', async (req: Request, res: Response) => {
    const period = String(req.query.period || 'weekly').toLowerCase();
    if (!ALLOWED_PERIODS.has(period)) {
      res.status(400).json({ ok: false, error: 'Unsupported report period.' });
      return;
    }
    try {
      const result = await callPythonBackend('report_preview', { period });
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to build report preview.' });
    }
  });

  app.get('/api/reports/export', async (req: Request, res: Response) => {
    const period = String(req.query.period || 'weekly').toLowerCase();
    const format = String(req.query.format || 'markdown').toLowerCase();
    if (!ALLOWED_PERIODS.has(period)) {
      res.status(400).json({ ok: false, error: 'Unsupported report period.' });
      return;
    }
    if (!ALLOWED_FORMATS.has(format)) {
      res.status(400).json({ ok: false, error: 'Unsupported report format.' });
      return;
    }
    try {
      const result = await callPythonBackend<{
        filename: string;
        mime: string;
        is_binary: boolean;
        content?: string;
        base64?: string;
      }>('export_report', { period, format });

      if (!result.ok || !result.data) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.setHeader('Content-Type', result.data.mime);
      res.setHeader('Content-Disposition', `attachment; filename="${result.data.filename}"`);
      if (result.data.is_binary && result.data.base64) {
        res.send(Buffer.from(result.data.base64, 'base64'));
      } else {
        res.send(result.data.content || '');
      }
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to export report.' });
    }
  });

  const allowedCharts = new Set([
    'weekly_trend',
    'monthly_trend',
    'duration_distribution',
    'goal_progress',
    'consistency_trend',
  ]);

  app.get('/api/charts/:kind', async (req: Request, res: Response) => {
    const chartKind = String(req.params.kind || '');
    if (!allowedCharts.has(chartKind)) {
      res.status(400).json({ ok: false, error: 'Unsupported chart type.' });
      return;
    }
    try {
      const result = await callPythonBackend<{
        filename: string;
        mime: string;
        base64: string;
        engine: string;
      }>('generate_chart', { chart_kind: chartKind });
      if (!result.ok || !result.data) {
        res.status(400).json({ ok: false, error: 'Chart generation failed.' });
        return;
      }
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('X-Chart-Engine', result.data.engine);
      res.send(Buffer.from(result.data.base64, 'base64'));
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to render analytical PNG chart.' });
    }
  });

  app.post('/api/import/csv', async (req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('import_csv', {
        csv_content: String(req.body?.csv_content || ''),
        preview_only: Boolean(req.body?.preview_only),
      });
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to process CSV import.' });
    }
  });

  app.get('/api/settings', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('get_settings');
      if (!result.ok) {
        res.status(500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to load settings.' });
    }
  });

  app.put('/api/settings', async (req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('save_settings', req.body || {});
      if (!result.ok) {
        res.status(result.status || 400).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to save settings.' });
    }
  });

  app.post('/api/demo/reset', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('reset_demo');
      if (!result.ok) {
        res.status(500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to reset demonstration dataset.' });
    }
  });

  app.post('/api/records/clear', async (_req: Request, res: Response) => {
    try {
      const result = await callPythonBackend('clear_records');
      if (!result.ok) {
        res.status(500).json(result);
        return;
      }
      res.json({ ok: true, ...(result.data || {}) });
    } catch {
      res.status(500).json({ ok: false, error: 'Failed to clear records.' });
    }
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`SleepNova running on http://0.0.0.0:${PORT} (Python backend bridge active)`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start SleepNova server:', err);
  process.exit(1);
});
