import React, { useState } from 'react';
import {
  BarChart3,
  Clock3,
  FileSpreadsheet,
  Info,
  LayoutDashboard,
  Menu,
  Moon,
  PlusCircle,
  Settings,
  X,
} from 'lucide-react';
import type { AppRoute } from '../types/sleep';
import { BrandMark } from './BrandMark';

interface AppShellProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
  breadcrumbTitle: string;
  children: React.ReactNode;
}

const NAV_ITEMS: Array<{
  route: AppRoute;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { route: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { route: '/logger', label: 'Log Sleep', icon: PlusCircle },
  { route: '/history', label: 'Sleep History', icon: Clock3 },
  { route: '/analytics', label: 'Analytics', icon: BarChart3 },
  { route: '/reports', label: 'Reports', icon: FileSpreadsheet },
  { route: '/settings', label: 'Settings', icon: Settings },
  { route: '/about', label: 'About SleepNova', icon: Info },
];

export const AppShell: React.FC<AppShellProps> = ({
  currentRoute,
  onNavigate,
  breadcrumbTitle,
  children,
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const handleNav = (route: AppRoute) => {
    setMobileOpen(false);
    onNavigate(route);
  };

  return (
    <div className="min-h-screen bg-[#080B16] text-[#F4F5FF] flex">
      {/* Desktop Sidebar */}
      <aside className="no-print hidden lg:flex lg:flex-col lg:w-64 lg:shrink-0 bg-[#101629] border-r border-[rgba(255,255,255,0.08)]">
        <div className="h-16 px-6 flex items-center border-b border-[rgba(255,255,255,0.08)]">
          <button
            type="button"
            onClick={() => handleNav('/')}
            className="flex items-center gap-2.5 text-left focus-visible:outline-none whitespace-nowrap shrink-0"
          >
            <BrandMark className="w-7 h-7" />
            <span className="font-display text-lg font-semibold tracking-tight text-[#F4F5FF]">
              SleepNova
            </span>
          </button>
        </div>

        <nav className="flex-1 px-3 py-5 space-y-1" aria-label="Workspace navigation">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = currentRoute === item.route;
            return (
              <button
                key={item.route}
                type="button"
                onClick={() => handleNav(item.route)}
                aria-current={active ? 'page' : undefined}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  active
                    ? 'bg-[#1B2440] text-[#F4F5FF] border border-[rgba(149,133,255,0.35)]'
                    : 'text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#151D34] border border-transparent'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${active ? 'text-[#9585FF]' : 'text-[#A0A8C0]'}`}
                />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-[rgba(255,255,255,0.08)]">
          <button
            type="button"
            onClick={() => handleNav('/')}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-medium text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#151D34] transition-colors whitespace-nowrap"
          >
            <Moon className="w-3.5 h-3.5 text-[#54D9C6]" />
            <span>Landing Overview</span>
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-black/70 backdrop-blur-xs"
            onClick={() => setMobileOpen(false)}
            aria-hidden="true"
          />
          <aside className="relative z-10 w-68 max-w-[82vw] bg-[#101629] border-r border-[rgba(255,255,255,0.08)] flex flex-col">
            <div className="h-16 px-5 flex items-center justify-between border-b border-[rgba(255,255,255,0.08)]">
              <button
                type="button"
                onClick={() => handleNav('/')}
                className="flex items-center gap-2.5 whitespace-nowrap shrink-0"
              >
                <BrandMark className="w-6 h-6" />
                <span className="font-display text-base font-semibold text-[#F4F5FF]">
                  SleepNova
                </span>
              </button>
              <button
                type="button"
                onClick={() => setMobileOpen(false)}
                aria-label="Close navigation menu"
                className="p-2 rounded-lg text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#151D34]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 px-3 py-4 space-y-1" aria-label="Mobile workspace navigation">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = currentRoute === item.route;
                return (
                  <button
                    key={item.route}
                    type="button"
                    onClick={() => handleNav(item.route)}
                    className={`w-full flex items-center gap-3 px-3.5 py-3 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
                      active
                        ? 'bg-[#1B2440] text-[#F4F5FF] border border-[rgba(149,133,255,0.35)]'
                        : 'text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#151D34] border border-transparent'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#9585FF]' : ''}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Bar Contract: Breadcrumb on left, 1 primary CTA on right */}
        <header className="no-print h-16 px-4 sm:px-6 lg:px-8 border-b border-[rgba(255,255,255,0.08)] bg-[#080B16]/90 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileOpen(true)}
              aria-label="Open navigation menu"
              className="lg:hidden p-2 -ml-2 rounded-lg text-[#A0A8C0] hover:text-[#F4F5FF] hover:bg-[#151D34]"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 text-sm truncate">
              <span className="text-[#A0A8C0]">SleepNova</span>
              <span className="text-[#A0A8C0]/50" aria-hidden="true">
                /
              </span>
              <span className="font-medium text-[#F4F5FF] truncate">{breadcrumbTitle}</span>
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0">
            {currentRoute !== '/logger' ? (
              <button
                type="button"
                onClick={() => handleNav('/logger')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] text-[#080B16] text-xs sm:text-sm font-semibold transition-colors whitespace-nowrap shrink-0"
              >
                <PlusCircle className="w-4 h-4 shrink-0" />
                <span>Log Sleep</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => handleNav('/dashboard')}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-[#F4F5FF] text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0"
              >
                <LayoutDashboard className="w-4 h-4 shrink-0 text-[#54D9C6]" />
                <span>View Dashboard</span>
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-6 lg:py-8 max-w-[1360px] w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
