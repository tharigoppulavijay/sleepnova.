import React from 'react';

interface BrandMarkProps {
  className?: string;
}

export const BrandMark: React.FC<BrandMarkProps> = ({ className = 'w-6 h-6' }) => (
  <svg
    viewBox="0 0 28 28"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <rect x="1.5" y="1.5" width="25" height="25" rx="7" fill="#151D34" stroke="rgba(255,255,255,0.12)" />
    <path
      d="M17.8 8.2C14.1 8.5 11.2 11.6 11.2 15.4C11.2 19.3 14.3 22.4 18.2 22.4C19.2 22.4 20.1 22.2 21 21.8C19.6 23.1 17.7 23.9 15.6 23.9C11.1 23.9 7.5 20.3 7.5 15.8C7.5 11.3 11.1 7.7 15.6 7.7C16.4 7.7 17.1 7.9 17.8 8.2Z"
      fill="#9585FF"
    />
    <path
      d="M15.5 14.2C17.1 14.2 17.8 11.8 19.4 11.8C20.5 11.8 21.2 12.9 22 13.5"
      stroke="#54D9C6"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
  </svg>
);
