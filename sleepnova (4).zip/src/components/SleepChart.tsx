import React, { useEffect, useId, useRef } from 'react';
import Chart, { type ChartConfiguration, type ChartData, type ChartOptions } from 'chart.js/auto';

interface SleepChartProps {
  type: 'bar' | 'line';
  data: ChartData<'bar' | 'line'>;
  options?: ChartOptions<'bar' | 'line'>;
  heightClass?: string;
  ariaLabel: string;
  description?: string;
}

export const SleepChart: React.FC<SleepChartProps> = ({
  type,
  data,
  options,
  heightClass = 'h-72',
  ariaLabel,
  description,
}) => {
  const descId = useId();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartRef = useRef<Chart | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (chartRef.current) {
      chartRef.current.destroy();
    }

    const defaultOptions: ChartOptions<'bar' | 'line'> = {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        duration: 320,
      },
      interaction: {
        mode: 'index',
        intersect: false,
      },
      plugins: {
        legend: {
          labels: {
            color: '#A0A8C0',
            font: {
              family: "'DM Sans', sans-serif",
              size: 12,
            },
            boxWidth: 10,
            usePointStyle: true,
          },
        },
        tooltip: {
          backgroundColor: '#101629',
          titleColor: '#F4F5FF',
          bodyColor: '#C5A8FF',
          borderColor: 'rgba(255,255,255,0.12)',
          borderWidth: 1,
          padding: 10,
          titleFont: { family: "'Plus Jakarta Sans', sans-serif", size: 12, weight: 600 },
          bodyFont: { family: "'JetBrains Mono', monospace", size: 12 },
        },
      },
      scales: {
        x: {
          grid: {
            color: 'rgba(255,255,255,0.04)',
          },
          ticks: {
            color: '#A0A8C0',
            font: {
              family: "'JetBrains Mono', monospace",
              size: 11,
            },
          },
          border: {
            color: 'rgba(255,255,255,0.08)',
          },
        },
        y: {
          grid: {
            color: 'rgba(255,255,255,0.06)',
          },
          ticks: {
            color: '#A0A8C0',
            font: {
              family: "'JetBrains Mono', monospace",
              size: 11,
            },
          },
          border: {
            color: 'rgba(255,255,255,0.08)',
          },
        },
      },
    };

    const mergedOptions: ChartOptions<'bar' | 'line'> = {
      ...defaultOptions,
      ...options,
      plugins: {
        ...defaultOptions.plugins,
        ...options?.plugins,
      },
      scales: {
        ...defaultOptions.scales,
        ...options?.scales,
      },
    };

    const config: ChartConfiguration<'bar' | 'line'> = {
      type,
      data,
      options: mergedOptions,
    };

    chartRef.current = new Chart(canvas, config);

    return () => {
      if (chartRef.current) {
        chartRef.current.destroy();
        chartRef.current = null;
      }
    };
  }, [type, data, options]);

  return (
    <div className={`relative w-full ${heightClass}`}>
      <canvas
        ref={canvasRef}
        aria-label={ariaLabel}
        aria-describedby={description ? descId : undefined}
        role="img"
      />
      {description && (
        <span id={descId} className="sr-only">
          {description}
        </span>
      )}
    </div>
  );
};
