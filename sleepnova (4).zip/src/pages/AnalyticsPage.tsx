import React, { useEffect, useMemo, useState } from 'react';
import { Download } from 'lucide-react';
import { sleepApi } from '../api/client';
import { SleepChart } from '../components/SleepChart';
import type { ExecutiveSummary } from '../types/sleep';

export const AnalyticsPage: React.FC = () => {
  const [summary, setSummary] = useState<ExecutiveSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pngKind, setPngKind] = useState<
    'weekly_trend' | 'monthly_trend' | 'duration_distribution' | 'goal_progress' | 'consistency_trend'
  >('weekly_trend');
  const [pngRefreshKey, setPngRefreshKey] = useState(0);

  useEffect(() => {
    let active = true;
    sleepApi
      .getSummary()
      .then((res) => {
        if (active) setSummary(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Failed to load analytics.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const weeklyBarData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const series = summary.weekly.daily_series;
    const goal = summary.weekly.stats.goal_hours;
    return {
      labels: series.map((d) => d.label),
      datasets: [
        {
          label: 'Duration (hrs)',
          data: series.map((d) => d.duration_hours ?? 0),
          backgroundColor: series.map((d) =>
            !d.has_record
              ? 'rgba(255,255,255,0.04)'
              : (d.duration_hours || 0) >= goal
                ? '#54D9C6'
                : '#9585FF',
          ),
          borderRadius: 6,
          barPercentage: 0.56,
        },
        {
          label: `Goal (${goal}h)`,
          data: series.map(() => goal),
          type: 'line' as const,
          borderColor: 'rgba(197,168,255,0.7)',
          borderDash: [5, 5],
          borderWidth: 1.5,
          pointRadius: 0,
        },
      ],
    };
  }, [summary]);

  const monthlyLineData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const series = summary.monthly.daily_series;
    return {
      labels: series.map((d) => d.label),
      datasets: [
        {
          label: 'Sleep Duration (hrs)',
          data: series.map((d) => d.duration_hours),
          borderColor: '#9585FF',
          backgroundColor: 'rgba(149,133,255,0.16)',
          fill: true,
          spanGaps: true,
          tension: 0.28,
          pointRadius: 2.5,
          pointBackgroundColor: '#54D9C6',
        },
      ],
    };
  }, [summary]);

  const distributionData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const dist = summary.monthly.distribution;
    return {
      labels: dist.map((b) => b.label),
      datasets: [
        {
          label: 'Sessions Count',
          data: dist.map((b) => b.count),
          backgroundColor: '#C5A8FF',
          borderRadius: 6,
          barPercentage: 0.6,
        },
      ],
    };
  }, [summary]);

  const goalProgressData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const gp = summary.goal_progress_weekly || [];
    return {
      labels: gp.map((g) => g.label),
      datasets: [
        {
          label: 'Goal Met (%)',
          data: gp.map((g) => g.goal_pct),
          backgroundColor: gp.map((g) => (g.goal_pct >= 70 ? '#54D9C6' : '#9585FF')),
          borderRadius: 6,
          barPercentage: 0.55,
        },
      ],
    };
  }, [summary]);

  const bedtimeConsistencyData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const pts = summary.monthly.consistency_series;
    return {
      labels: pts.map((p) => p.date.slice(5)),
      datasets: [
        {
          label: 'Bedtime Offset from Midnight (hrs)',
          data: pts.map((p) => p.bedtime_offset_hours),
          borderColor: '#9585FF',
          backgroundColor: 'rgba(149,133,255,0.12)',
          tension: 0.25,
          pointRadius: 3,
          pointBackgroundColor: '#C5A8FF',
        },
      ],
    };
  }, [summary]);

  const wakeConsistencyData = useMemo(() => {
    if (!summary) return { labels: [], datasets: [] };
    const pts = summary.monthly.consistency_series;
    return {
      labels: pts.map((p) => p.date.slice(5)),
      datasets: [
        {
          label: 'Wake-up Clock Hour (24h)',
          data: pts.map((p) => p.wake_time_hours),
          borderColor: '#54D9C6',
          backgroundColor: 'rgba(84,217,198,0.12)',
          tension: 0.25,
          pointRadius: 3,
          pointBackgroundColor: '#54D9C6',
        },
      ],
    };
  }, [summary]);

  if (loading) {
    return <div className="p-8 text-xs text-[#A0A8C0]">Computing Python sleep analytics...</div>;
  }

  if (error || !summary) {
    return (
      <div className="p-6 rounded-xl bg-[#151D34] border border-red-400/40 text-sm text-red-300">
        {error || 'Unable to compute analytics.'}
      </div>
    );
  }

  const wStats = summary.weekly.stats;
  const mStats = summary.monthly.stats;
  const cons = summary.overall.consistency;

  if (summary.overall.stats.record_count === 0) {
    return (
      <div className="p-10 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] text-center max-w-2xl mx-auto">
        <h1 className="font-display text-xl font-semibold text-[#F4F5FF] mb-2">
          No analytics available yet
        </h1>
        <p className="text-sm text-[#A0A8C0]">
          Log sleep records or restore the demonstration dataset in Settings to populate weekly,
          monthly, goal completion, and consistency visualizations.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
          Sleep Analytics Engine
        </h1>
        <p className="text-sm text-[#A0A8C0] mt-1">
          Weekly, monthly, goal attainment, distribution, and circular bedtime consistency analysis
          computed from <span className="font-mono text-[#F4F5FF]">{summary.overall.stats.record_count}</span>{' '}
          stored record(s). Unlogged dates remain blank and are never fabricated.
        </p>
      </div>

      {/* Weekly + Monthly Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-2">
          <p className="text-xs font-medium text-[#54D9C6]">Weekly Scope (7 Days)</p>
          <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F5FF]">
            {wStats.average_formatted}{' '}
            <span className="text-xs font-normal text-[#A0A8C0]">avg</span>
          </p>
          <div className="text-xs text-[#A0A8C0] font-mono tabular-nums space-y-1 pt-2 border-t border-[rgba(255,255,255,0.06)]">
            <div>Total: {wStats.total_formatted} ({wStats.record_count} records)</div>
            <div>
              Shortest: {wStats.shortest_session ? wStats.shortest_session.formatted : '—'} ·
              Longest: {wStats.longest_session ? wStats.longest_session.formatted : '—'}
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-2">
          <p className="text-xs font-medium text-[#9585FF]">Monthly Scope (30 Days)</p>
          <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F5FF]">
            {mStats.average_formatted}{' '}
            <span className="text-xs font-normal text-[#A0A8C0]">avg</span>
          </p>
          <div className="text-xs text-[#A0A8C0] font-mono tabular-nums space-y-1 pt-2 border-t border-[rgba(255,255,255,0.06)]">
            <div>Total: {mStats.total_formatted} ({mStats.record_count} records)</div>
            <div>
              Median: {mStats.median_hours}h · Goal Met: {mStats.goal_achievement_pct}%
            </div>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-2">
          <p className="text-xs font-medium text-[#C5A8FF]">Schedule Regularity</p>
          <p className="font-mono text-2xl font-semibold tabular-nums text-[#F4F5FF]">
            {cons.sufficient_data ? `${cons.consistency_score}%` : 'Insufficient Data'}
          </p>
          <div className="text-xs text-[#A0A8C0] font-mono tabular-nums space-y-1 pt-2 border-t border-[rgba(255,255,255,0.06)]">
            {cons.sufficient_data ? (
              <>
                <div>Mean Bedtime: {cons.average_bedtime} (σ = {cons.bedtime_stdev_minutes}m)</div>
                <div>Mean Wake: {cons.average_wake_time} (σ = {cons.wake_stdev_minutes}m)</div>
              </>
            ) : (
              <div>{cons.explanation}</div>
            )}
          </div>
        </div>
      </div>

      {/* Chart 1 & Chart 2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            1. Weekly Sleep Duration Bar Chart
          </h2>
          <p className="text-xs text-[#A0A8C0] font-mono mb-4">
            {summary.weekly.period_start} to {summary.weekly.period_end} · Missing days:{' '}
            {summary.weekly.missing_days_count}
          </p>
          <SleepChart
            type="bar"
            data={weeklyBarData}
            options={{ scales: { y: { min: 0, max: 12 } } }}
            ariaLabel="Weekly sleep duration bar chart"
          />
        </div>

        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            2. Monthly Sleep Trend Line Chart
          </h2>
          <p className="text-xs text-[#A0A8C0] font-mono mb-4">
            {summary.monthly.period_start} to {summary.monthly.period_end}
          </p>
          <SleepChart
            type="line"
            data={monthlyLineData}
            options={{ scales: { y: { min: 0, max: 13 } } }}
            ariaLabel="Monthly sleep trend line chart"
          />
        </div>
      </div>

      {/* Chart 3 (Distribution) & Chart 4 (Goal Progress) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            3. Sleep Duration Distribution (30 Days)
          </h2>
          <p className="text-xs text-[#A0A8C0] mb-4">
            Frequency of logged sessions grouped by duration bucket
          </p>
          <SleepChart
            type="bar"
            data={distributionData}
            options={{ scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }}
            heightClass="h-64"
            ariaLabel="Sleep duration distribution chart"
          />
        </div>

        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            4. Weekly Goal Completion Progress
          </h2>
          <p className="text-xs text-[#A0A8C0] mb-4">
            Share of sessions meeting your {wStats.goal_hours}h target across 4 trailing weeks
          </p>
          <SleepChart
            type="bar"
            data={goalProgressData}
            options={{ scales: { y: { min: 0, max: 100 } } }}
            heightClass="h-64"
            ariaLabel="Weekly goal completion progress chart"
          />
        </div>
      </div>

      {/* Chart 5 & Chart 6: Bedtime & Wake-up Consistency */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            5. Bedtime Consistency Chart
          </h2>
          <p className="text-xs text-[#A0A8C0] mb-4">
            Hours relative to 00:00 midnight (e.g., -1.5 = 22:30, +0.5 = 00:30)
          </p>
          <SleepChart
            type="line"
            data={bedtimeConsistencyData}
            heightClass="h-64"
            ariaLabel="Bedtime consistency chart"
          />
        </div>

        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            6. Wake-up Consistency Chart
          </h2>
          <p className="text-xs text-[#A0A8C0] mb-4">
            Wake-up hour on a 24-hour clock across recent sessions
          </p>
          <SleepChart
            type="line"
            data={wakeConsistencyData}
            options={{ scales: { y: { min: 4, max: 13 } } }}
            heightClass="h-64"
            ariaLabel="Wake-up consistency chart"
          />
        </div>
      </div>

      {/* Weekly Comparison Table + Metric Derivation */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-6 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)]">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF] mb-1">
            4-Week Rolling Comparison
          </h2>
          <p className="text-xs text-[#A0A8C0] mb-4">
            Trailing 7-day blocks across the past month
          </p>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-[rgba(255,255,255,0.08)] text-[#A0A8C0]">
                  <th className="py-2.5 pr-3 font-medium">Week Window</th>
                  <th className="py-2.5 px-3 font-medium text-right">Records</th>
                  <th className="py-2.5 px-3 font-medium text-right">Avg (hrs)</th>
                  <th className="py-2.5 pl-3 font-medium text-right">Total (hrs)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[rgba(255,255,255,0.06)] font-mono tabular-nums">
                {summary.monthly.weekly_comparison.map((wk) => (
                  <tr key={wk.label}>
                    <td className="py-3 pr-3 text-[#F4F5FF]">{wk.label}</td>
                    <td className="py-3 px-3 text-right text-[#A0A8C0]">{wk.record_count}</td>
                    <td className="py-3 px-3 text-right text-[#54D9C6]">{wk.average_hours.toFixed(2)}h</td>
                    <td className="py-3 pl-3 text-right text-[#C5A8FF]">{wk.total_hours.toFixed(1)}h</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-6 p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-3">
          <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
            Metric Derivation &amp; Calculation Methodology
          </h2>
          <dl className="space-y-2.5 text-xs">
            <div>
              <dt className="font-semibold text-[#C5A8FF]">Sleep Duration</dt>
              <dd className="text-[#A0A8C0] mt-0.5">{summary.methodology.duration}</dd>
            </div>
            <div>
              <dt className="font-semibold text-[#C5A8FF]">Period Averages</dt>
              <dd className="text-[#A0A8C0] mt-0.5">{summary.methodology.averages}</dd>
            </div>
            <div>
              <dt className="font-semibold text-[#C5A8FF]">Schedule Consistency</dt>
              <dd className="text-[#A0A8C0] mt-0.5">{summary.methodology.consistency}</dd>
            </div>
            {summary.methodology.goal_completion && (
              <div>
                <dt className="font-semibold text-[#C5A8FF]">Goal Completion</dt>
                <dd className="text-[#A0A8C0] mt-0.5">{summary.methodology.goal_completion}</dd>
              </div>
            )}
          </dl>
        </div>
      </div>

      {/* Python Server-Generated PNG Chart Export Preview */}
      <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
              Python Analytical PNG Chart Export
            </h2>
            <p className="text-xs text-[#A0A8C0] mt-0.5">
              Rendered by <span className="font-mono text-[#F4F5FF]">backend/plotting.py</span>{' '}
              (Matplotlib when installed locally, stdlib PNG fallback in sandboxed runtimes)
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {(
              [
                ['weekly_trend', 'Weekly'],
                ['monthly_trend', 'Monthly'],
                ['duration_distribution', 'Distribution'],
                ['goal_progress', 'Goal Progress'],
                ['consistency_trend', 'Consistency'],
              ] as const
            ).map(([kind, label]) => (
              <button
                key={kind}
                type="button"
                onClick={() => {
                  setPngKind(kind);
                  setPngRefreshKey((k) => k + 1);
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  pngKind === kind
                    ? 'bg-[#9585FF] text-[#080B16]'
                    : 'bg-[#101629] text-[#A0A8C0] hover:text-[#F4F5FF]'
                }`}
              >
                {label}
              </button>
            ))}
            <a
              href={`/api/charts/${pngKind}`}
              download={`sleepnova_${pngKind}.png`}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#1B2440] border border-[rgba(255,255,255,0.12)] text-xs font-medium text-[#54D9C6]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PNG</span>
            </a>
          </div>
        </div>

        <div className="rounded-lg overflow-hidden border border-[rgba(255,255,255,0.08)] bg-[#080B16]">
          <img
            src={`/api/charts/${pngKind}?v=${pngRefreshKey}`}
            alt={`Python-generated ${pngKind} analytical sleep chart`}
            className="w-full max-h-[380px] object-contain mx-auto"
          />
        </div>
      </div>
    </div>
  );
};
