import React, { useEffect, useState } from 'react';
import { Download, FileCode2, FileSpreadsheet, FileText, Image as ImageIcon, Printer } from 'lucide-react';
import { sleepApi } from '../api/client';
import type { ReportPreview } from '../types/sleep';

type PeriodOption = 'daily' | 'weekly' | 'monthly' | 'all';
type PreviewTab = 'summary' | 'markdown' | 'txt';

export const ReportsPage: React.FC = () => {
  const [period, setPeriod] = useState<PeriodOption>('weekly');
  const [previewTab, setPreviewTab] = useState<PreviewTab>('summary');
  const [report, setReport] = useState<ReportPreview | null>(null);
  const [rawTextPreview, setRawTextPreview] = useState<string>('');
  const [loadingRaw, setLoadingRaw] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    sleepApi
      .getReportPreview(period)
      .then((res) => {
        if (active) setReport(res);
      })
      .catch((err) => {
        if (active) setError(err instanceof Error ? err.message : 'Failed to build report.');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [period]);

  useEffect(() => {
    if (previewTab === 'summary') return;
    let active = true;
    setLoadingRaw(true);
    fetch(`/api/reports/export?period=${period}&format=${previewTab}`)
      .then((res) => {
        if (!res.ok) throw new Error('Unable to load text preview.');
        return res.text();
      })
      .then((txt) => {
        if (active) setRawTextPreview(txt);
      })
      .catch((err) => {
        if (active) setRawTextPreview(err instanceof Error ? err.message : 'Preview unavailable.');
      })
      .finally(() => {
        if (active) setLoadingRaw(false);
      });
    return () => {
      active = false;
    };
  }, [period, previewTab]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
            Executive Report Center
          </h1>
          <p className="text-sm text-[#A0A8C0] mt-1">
            Generate structured Daily, Weekly, Monthly, or Complete Historical reports in five
            portable export formats.
          </p>
        </div>

        <div className="no-print flex flex-wrap items-center gap-3 self-start">
          {/* Period Segmented Selector */}
          <div className="inline-flex items-center gap-1 p-1 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.08)]">
            {(
              [
                ['daily', 'Daily'],
                ['weekly', 'Weekly'],
                ['monthly', 'Monthly'],
                ['all', 'All History'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setPeriod(key)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                  period === key
                    ? 'bg-[#9585FF] text-[#080B16]'
                    : 'text-[#A0A8C0] hover:text-[#F4F5FF]'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-xs font-medium text-[#F4F5FF] transition-colors whitespace-nowrap"
          >
            <Printer className="w-3.5 h-3.5 text-[#54D9C6]" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Export Action Strip */}
      <div className="no-print grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        {[
          { fmt: 'csv', label: 'Export CSV', sub: 'Spreadsheet data', icon: FileSpreadsheet },
          { fmt: 'json', label: 'Export JSON', sub: 'Structured schema', icon: FileCode2 },
          { fmt: 'markdown', label: 'Markdown (.md)', sub: 'Formatted summary', icon: FileText },
          { fmt: 'txt', label: 'Audit Log (.txt)', sub: 'Fixed-width log', icon: Download },
          { fmt: 'png', label: 'PNG Chart', sub: 'Analytical visual', icon: ImageIcon },
        ].map((item) => {
          const Icon = item.icon;
          return (
            <a
              key={item.fmt}
              href={`/api/reports/export?period=${period}&format=${item.fmt}`}
              download
              className="p-4 rounded-xl bg-[#151D34] hover:bg-[#1B2440] border border-[rgba(255,255,255,0.08)] transition-colors flex flex-col gap-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#F4F5FF]">{item.label}</span>
                <Icon className="w-4 h-4 text-[#54D9C6]" />
              </div>
              <span className="text-xs text-[#A0A8C0]">{item.sub}</span>
            </a>
          );
        })}
      </div>

      {/* Preview Mode Switcher */}
      <div className="no-print inline-flex items-center gap-1 p-1 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.08)]">
        {(
          [
            ['summary', 'Overview Preview'],
            ['markdown', 'Markdown (.md) Preview'],
            ['txt', 'Plain-Text (.txt) Preview'],
          ] as const
        ).map(([tabKey, tabLabel]) => (
          <button
            key={tabKey}
            type="button"
            onClick={() => setPreviewTab(tabKey)}
            className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
              previewTab === tabKey
                ? 'bg-[#1B2440] text-[#F4F5FF] border border-[rgba(255,255,255,0.12)]'
                : 'text-[#A0A8C0] hover:text-[#F4F5FF]'
            }`}
          >
            {tabLabel}
          </button>
        ))}
      </div>

      {/* Report Preview Document */}
      {loading ? (
        <div className="p-8 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] text-xs text-[#A0A8C0]">
          Compiling executive summary in Python...
        </div>
      ) : error || !report ? (
        <div className="p-6 rounded-xl bg-[#151D34] border border-red-400/40 text-xs text-red-300">
          {error}
        </div>
      ) : previewTab !== 'summary' ? (
        <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-3">
          <div className="flex items-center justify-between gap-3">
            <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
              {previewTab === 'markdown' ? 'Markdown Report Output' : 'Plain-Text Audit Log Output'}
            </h2>
            <a
              href={`/api/reports/export?period=${period}&format=${previewTab}`}
              download
              className="text-xs font-medium text-[#54D9C6] hover:underline"
            >
              Download .{previewTab === 'markdown' ? 'md' : 'txt'}
            </a>
          </div>
          {loadingRaw ? (
            <p className="text-xs text-[#A0A8C0]">Generating export text from Python...</p>
          ) : (
            <pre className="p-4 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.08)] text-xs font-mono text-[#E2E6FF] overflow-x-auto whitespace-pre leading-relaxed max-h-[480px] overflow-y-auto">
              {rawTextPreview}
            </pre>
          )}
        </div>
      ) : (
        <div className="print-surface p-6 sm:p-8 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-[rgba(255,255,255,0.08)]">
            <div>
              <h2 className="font-display text-xl font-bold text-[#F4F5FF]">{report.title}</h2>
              <p className="text-xs font-mono text-[#A0A8C0] mt-1">
                Period: {report.period_label} · Generated: {report.generated_at}
              </p>
            </div>
            <div className="text-xs font-mono text-[#54D9C6]">
              {report.record_count} record(s) included
            </div>
          </div>

          {report.record_count === 0 && (
            <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.08)] text-xs text-[#A0A8C0]">
              No sleep records fall inside the selected <span className="font-mono text-[#F4F5FF]">{report.period_label}</span>{' '}
              window. Export files remain valid and reflect zero included sessions.
            </div>
          )}

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)]">
              <p className="text-xs text-[#A0A8C0]">Total Sleep</p>
              <p className="font-mono text-lg font-semibold tabular-nums text-[#F4F5FF] mt-1">
                {report.total_duration}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)]">
              <p className="text-xs text-[#A0A8C0]">Average Duration</p>
              <p className="font-mono text-lg font-semibold tabular-nums text-[#54D9C6] mt-1">
                {report.average_duration}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)]">
              <p className="text-xs text-[#A0A8C0]">Longest / Shortest</p>
              <p className="font-mono text-xs tabular-nums text-[#F4F5FF] mt-1.5">
                Max: {report.longest_session}
              </p>
              <p className="font-mono text-xs tabular-nums text-[#A0A8C0]">
                Min: {report.shortest_session}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)]">
              <p className="text-xs text-[#A0A8C0]">Goal Attainment ({report.goal_hours}h)</p>
              <p className="font-mono text-lg font-semibold tabular-nums text-[#9585FF] mt-1">
                {report.goal_achievement_pct}%
              </p>
            </div>
          </div>

          {(report.weekly_trends || report.monthly_trends) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {report.weekly_trends && (
                <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)] space-y-1">
                  <p className="text-xs font-semibold text-[#C5A8FF]">
                    Weekly Trends ({report.weekly_trends.period_label})
                  </p>
                  <p className="text-xs text-[#A0A8C0] leading-relaxed">
                    {report.weekly_trends.summary_text}
                  </p>
                </div>
              )}
              {report.monthly_trends && (
                <div className="p-4 rounded-lg bg-[#101629] border border-[rgba(255,255,255,0.06)] space-y-1">
                  <p className="text-xs font-semibold text-[#54D9C6]">
                    Monthly Trends ({report.monthly_trends.period_label})
                  </p>
                  <p className="text-xs text-[#A0A8C0] leading-relaxed">
                    {report.monthly_trends.summary_text}
                  </p>
                </div>
              )}
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-2">
            <div className="space-y-2">
              <h3 className="font-display text-sm font-semibold text-[#F4F5FF]">
                Consistency &amp; Trend Summary
              </h3>
              <p className="text-xs text-[#A0A8C0] leading-relaxed">{report.trend_summary}</p>
              {report.consistency.sufficient_data ? (
                <p className="text-xs font-mono text-[#C5A8FF]">
                  Consistency: {report.consistency.consistency_score}% ({report.consistency.rating_label}) ·
                  Mean Bedtime {report.consistency.average_bedtime} · Mean Wake{' '}
                  {report.consistency.average_wake_time}
                </p>
              ) : (
                <p className="text-xs text-[#A0A8C0]">{report.consistency.explanation}</p>
              )}
              <p className="text-xs text-[#A0A8C0]">
                Data Quality: {report.data_quality.user_records} personal record(s),{' '}
                {report.data_quality.demo_records} demonstration record(s).
              </p>
            </div>

            <div className="space-y-2">
              <h3 className="font-display text-sm font-semibold text-[#F4F5FF]">
                Threshold Indicators
              </h3>
              <ul className="space-y-1.5 text-xs text-[#A0A8C0]">
                {report.warnings.map((w) => (
                  <li key={w.id}>
                    <span className="font-semibold text-[#F4F5FF]">{w.title}:</span> {w.message}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
