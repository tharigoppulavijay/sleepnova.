import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, RotateCcw, Trash2 } from 'lucide-react';
import { sleepApi } from '../api/client';
import type { SleepSettings } from '../types/sleep';

export const SettingsPage: React.FC = () => {
  const [settings, setSettings] = useState<SleepSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<'reset_demo' | 'clear_all' | null>(null);
  const [mutating, setMutating] = useState(false);

  useEffect(() => {
    sleepApi
      .getSettings()
      .then((res) => setSettings(res.settings))
      .catch((err) => setErrorMsg(err instanceof Error ? err.message : 'Failed to load settings.'));
  }, []);

  useEffect(() => {
    if (!confirmAction) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !mutating) {
        setConfirmAction(null);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [confirmAction, mutating]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setSaving(true);
    setStatusMsg(null);
    setErrorMsg(null);
    try {
      const res = await sleepApi.saveSettings(settings);
      setSettings(res.settings);
      setStatusMsg('Settings validated and persisted to data/settings.json.');
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmDatasetAction = async () => {
    if (!confirmAction || mutating) return;
    setMutating(true);
    setStatusMsg(null);
    setErrorMsg(null);
    try {
      if (confirmAction === 'reset_demo') {
        const res = await sleepApi.resetDemo();
        setStatusMsg(`Restored ${res.record_count} demonstration records to CSV and JSON storage.`);
      } else {
        const res = await sleepApi.clearRecords();
        setStatusMsg(`Cleared ${res.removed_count} record(s). Local storage files are now empty.`);
      }
    } catch (err) {
      setErrorMsg(err instanceof Error ? err.message : 'Dataset operation failed.');
    } finally {
      setMutating(false);
      setConfirmAction(null);
    }
  };

  if (!settings) {
    return <div className="p-8 text-xs text-[#A0A8C0]">Loading settings...</div>;
  }

  return (
    <div className="space-y-8 max-w-4xl">
      <div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-tight text-[#F4F5FF]">
          Settings &amp; Personalization
        </h1>
        <p className="text-sm text-[#A0A8C0] mt-1">
          Configure sleep goals, warning thresholds, display formats, and manage your local dataset.
        </p>
      </div>

      {statusMsg && (
        <div
          role="status"
          className="p-3.5 rounded-xl bg-[#151D34] border border-[#54D9C6]/40 flex items-center gap-2.5 text-xs text-[#54D9C6]"
        >
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{statusMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div
          role="alert"
          className="p-3.5 rounded-xl bg-[#151D34] border border-red-400/40 flex items-center gap-2.5 text-xs text-red-300"
        >
          <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
          <span>{errorMsg}</span>
        </div>
      )}

      <form
        onSubmit={handleSave}
        className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-6"
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          <div>
            <label htmlFor="goal-hours" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Sleep Duration Goal (hours)
            </label>
            <input
              id="goal-hours"
              type="number"
              step="0.5"
              min="4"
              max="12"
              value={settings.sleep_goal_hours}
              onChange={(e) =>
                setSettings({ ...settings, sleep_goal_hours: Number(e.target.value) })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF]"
            />
          </div>

          <div>
            <label htmlFor="date-fmt" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Preferred Date Format
            </label>
            <select
              id="date-fmt"
              value={settings.preferred_date_format}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  preferred_date_format: e.target.value as SleepSettings['preferred_date_format'],
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm text-[#F4F5FF]"
            >
              <option value="YYYY-MM-DD">YYYY-MM-DD (ISO)</option>
              <option value="MM/DD/YYYY">MM/DD/YYYY</option>
              <option value="DD/MM/YYYY">DD/MM/YYYY</option>
              <option value="MMM DD, YYYY">MMM DD, YYYY</option>
            </select>
          </div>

          <div>
            <label htmlFor="short-threshold" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Short Session Warning Threshold (hours)
            </label>
            <input
              id="short-threshold"
              type="number"
              step="0.5"
              min="1"
              max="9"
              value={settings.short_sleep_threshold_hours}
              onChange={(e) =>
                setSettings({ ...settings, short_sleep_threshold_hours: Number(e.target.value) })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF]"
            />
          </div>

          <div>
            <label htmlFor="long-threshold" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Long Session Review Threshold (hours)
            </label>
            <input
              id="long-threshold"
              type="number"
              step="0.5"
              min="7"
              max="18"
              value={settings.long_sleep_threshold_hours}
              onChange={(e) =>
                setSettings({ ...settings, long_sleep_threshold_hours: Number(e.target.value) })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF]"
            />
          </div>

          <div>
            <label htmlFor="bedtime-var" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Bedtime Variance Alert (minutes std dev)
            </label>
            <input
              id="bedtime-var"
              type="number"
              min="15"
              max="240"
              value={settings.bedtime_variance_threshold_mins}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  bedtime_variance_threshold_mins: Number(e.target.value),
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm font-mono text-[#F4F5FF]"
            />
          </div>

          <div>
            <label htmlFor="export-fmt" className="block text-xs font-medium text-[#A0A8C0] mb-1.5">
              Default Report Export Format
            </label>
            <select
              id="export-fmt"
              value={settings.default_export_format}
              onChange={(e) =>
                setSettings({
                  ...settings,
                  default_export_format: e.target.value as SleepSettings['default_export_format'],
                })
              }
              className="w-full px-3.5 py-2.5 rounded-lg bg-[#080B16] border border-[rgba(255,255,255,0.12)] text-sm text-[#F4F5FF]"
            >
              <option value="csv">CSV</option>
              <option value="json">JSON</option>
              <option value="markdown">Markdown (.md)</option>
              <option value="txt">Plain-Text Audit Log (.txt)</option>
            </select>
          </div>
        </div>

        <label className="flex items-center gap-2.5 text-xs text-[#A0A8C0] cursor-pointer">
          <input
            type="checkbox"
            checked={settings.show_demo_banner}
            onChange={(e) => setSettings({ ...settings, show_demo_banner: e.target.checked })}
            className="rounded border-[rgba(255,255,255,0.2)] bg-[#080B16]"
          />
          <span>Display demonstration dataset disclosure banner on dashboard</span>
        </label>

        <div>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2.5 rounded-lg bg-[#9585FF] hover:bg-[#A698FF] disabled:opacity-60 text-[#080B16] text-sm font-semibold transition-colors"
          >
            {saving ? 'Saving...' : 'Save Preferences'}
          </button>
        </div>
      </form>

      {/* Dataset Reset & Clear Controls */}
      <div className="p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.08)] space-y-4">
        <h2 className="font-display text-base font-semibold text-[#F4F5FF]">
          Local Dataset Management
        </h2>
        <p className="text-xs text-[#A0A8C0] leading-relaxed">
          Reset local storage to the 39-record demonstration dataset for hackathon presentations, or
          clear all entries to start logging fresh personal records from an empty state.
        </p>
        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={() => setConfirmAction('reset_demo')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#1B2440] hover:bg-[#232E52] border border-[rgba(255,255,255,0.12)] text-xs font-medium text-[#F4F5FF]"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#54D9C6]" />
            <span>Reset to 39-Record Demo Dataset</span>
          </button>

          <button
            type="button"
            onClick={() => setConfirmAction('clear_all')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-[#101629] hover:bg-red-950/40 border border-red-400/30 text-xs font-medium text-red-300"
          >
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
            <span>Clear All Stored Records</span>
          </button>
        </div>
      </div>

      {confirmAction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
          <div
            role="dialog"
            aria-modal="true"
            className="w-full max-w-md p-6 rounded-xl bg-[#151D34] border border-[rgba(255,255,255,0.12)] space-y-4"
          >
            <h3 className="font-display text-lg font-semibold text-[#F4F5FF]">
              {confirmAction === 'reset_demo'
                ? 'Restore Demonstration Dataset?'
                : 'Clear All Stored Sleep Records?'}
            </h3>
            <p className="text-xs text-[#A0A8C0] leading-relaxed">
              {confirmAction === 'reset_demo'
                ? 'This replaces current JSON and CSV records with the 39 labeled demonstration entries.'
                : 'This deletes every record from sleep_records.json and sleep_records.csv. You can reload the demo dataset anytime.'}
            </p>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                disabled={mutating}
                onClick={() => setConfirmAction(null)}
                className="px-4 py-2 rounded-lg bg-[#1B2440] text-xs font-medium text-[#F4F5FF] disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={mutating}
                onClick={handleConfirmDatasetAction}
                className="px-4 py-2 rounded-lg bg-[#9585FF] text-xs font-semibold text-[#080B16] disabled:opacity-60"
              >
                {mutating ? 'Processing...' : 'Confirm Action'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
