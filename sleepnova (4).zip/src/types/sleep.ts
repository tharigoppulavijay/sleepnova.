export type AppRoute =
  | '/'
  | '/dashboard'
  | '/logger'
  | '/history'
  | '/analytics'
  | '/reports'
  | '/settings'
  | '/about';

export interface SleepRecord {
  id: string;
  sleep_date: string;
  bedtime: string;
  wake_date: string;
  wake_time: string;
  duration_minutes: number;
  duration_hours: number;
  notes: string;
  is_demo: boolean;
  created_at: string;
  updated_at: string;
}

export interface SleepSettings {
  sleep_goal_hours: number;
  short_sleep_threshold_hours: number;
  long_sleep_threshold_hours: number;
  bedtime_variance_threshold_mins: number;
  missing_days_threshold: number;
  preferred_date_format: 'YYYY-MM-DD' | 'MM/DD/YYYY' | 'DD/MM/YYYY' | 'MMM DD, YYYY';
  default_export_format: 'csv' | 'json' | 'markdown' | 'txt';
  show_demo_banner: boolean;
  dashboard_window_days: number;
}

export interface PeriodSessionRef {
  id: string;
  sleep_date: string;
  wake_date: string;
  duration_hours: number;
  duration_minutes: number;
  formatted: string;
}

export interface PeriodStats {
  record_count: number;
  total_minutes: number;
  total_hours: number;
  total_formatted: string;
  average_minutes: number;
  average_hours: number;
  average_formatted: string;
  median_hours: number;
  longest_session: PeriodSessionRef | null;
  shortest_session: PeriodSessionRef | null;
  goal_hours: number;
  goal_met_count: number;
  goal_achievement_pct: number;
  duration_stdev_hours: number;
}

export interface ConsistencyMetrics {
  sufficient_data: boolean;
  record_count: number;
  consistency_score: number | null;
  rating_label: string;
  average_bedtime: string | null;
  average_wake_time: string | null;
  bedtime_stdev_minutes: number | null;
  wake_stdev_minutes: number | null;
  explanation: string;
}

export interface DailySeriesPoint {
  date: string;
  label: string;
  short_day?: string;
  duration_hours: number | null;
  duration_minutes?: number | null;
  bedtime: string | null;
  wake_time: string | null;
  has_record: boolean;
}

export interface WarningIndicator {
  id: string;
  severity: 'info' | 'warning' | 'nominal';
  category: string;
  title: string;
  message: string;
  record_ids: string[];
}

export interface WeeklyAnalytics {
  period_start: string;
  period_end: string;
  previous_start: string;
  previous_end: string;
  stats: PeriodStats;
  previous_stats: PeriodStats;
  comparison: {
    average_delta_hours: number | null;
    total_delta_hours: number | null;
    record_count_delta: number;
  };
  daily_series: DailySeriesPoint[];
  consistency: ConsistencyMetrics;
  missing_days_count: number;
}

export interface MonthlyAnalytics {
  period_start: string;
  period_end: string;
  stats: PeriodStats;
  previous_stats: PeriodStats;
  comparison: {
    average_delta_hours: number | null;
    record_count_delta: number;
  };
  daily_series: DailySeriesPoint[];
  weekly_comparison: Array<{
    label: string;
    start_date: string;
    end_date: string;
    record_count: number;
    average_hours: number;
    total_hours: number;
  }>;
  distribution: Array<{
    label: string;
    min: number;
    max: number;
    count: number;
  }>;
  consistency_series: Array<{
    date: string;
    wake_date: string;
    bedtime: string;
    wake_time: string;
    bedtime_offset_hours: number;
    wake_time_hours: number;
    duration_hours: number;
  }>;
  consistency: ConsistencyMetrics;
}

export interface ExecutiveSummary {
  generated_at: string;
  reference_date: string;
  daily: {
    date: string;
    stats: PeriodStats;
    latest_session: SleepRecord | null;
  };
  weekly: WeeklyAnalytics;
  monthly: MonthlyAnalytics;
  overall: {
    stats: PeriodStats;
    consistency: ConsistencyMetrics;
    date_range: {
      earliest: string | null;
      latest: string | null;
      span_days: number;
    };
  };
  trend: {
    status: string;
    detail: string;
    weekly_delta_hours: number | null;
  };
  goal_progress_weekly: Array<{
    label: string;
    goal_pct: number;
    met_count: number;
    record_count: number;
  }>;
  insights: Array<{
    title: string;
    detail: string;
  }>;
  data_quality: {
    total_records: number;
    user_records: number;
    demo_records: number;
    coverage_pct: number;
    has_demo_data: boolean;
  };
  warnings: WarningIndicator[];
  methodology: {
    duration: string;
    averages: string;
    consistency: string;
    goal_completion?: string;
  };
}

export interface RecordsQueryResponse {
  ok: boolean;
  records: SleepRecord[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
  recovery_notice?: string | null;
}

export interface ImportCsvResult {
  ok: boolean;
  preview_only?: boolean;
  total_rows: number;
  imported_count: number;
  rejected_count: number;
  invalid_count: number;
  duplicate_count: number;
  imported_records: SleepRecord[];
  error_logs: Array<{
    row: number;
    category?: 'duplicate' | 'invalid';
    raw: Record<string, string>;
    error: string;
  }>;
}

export interface ReportTrendSummary {
  period_label: string;
  record_count: number;
  average_duration: string;
  average_hours: number;
  goal_achievement_pct: number;
  previous_delta_hours: number | null;
  missing_days_count?: number;
  consistency_score: number | null;
  summary_text: string;
}

export interface ReportPreview {
  ok: boolean;
  title: string;
  period: string;
  period_label: string;
  generated_at: string;
  record_count: number;
  total_duration: string;
  total_hours: number;
  average_duration: string;
  average_hours: number;
  longest_session: string;
  shortest_session: string;
  goal_hours: number;
  goal_met_count: number;
  goal_achievement_pct: number;
  consistency: ConsistencyMetrics;
  trend_summary: string;
  weekly_trends?: ReportTrendSummary;
  monthly_trends?: ReportTrendSummary;
  data_quality: {
    total_records: number;
    demo_records: number;
    user_records: number;
  };
  warnings: WarningIndicator[];
  records: SleepRecord[];
}
