window.SleepNova = {
  getCsrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute('content') || '' : '';
  },
  async api(url, options = {}) {
    const headers = new Headers(options.headers || {});
    headers.set('X-CSRF-Token', this.getCsrfToken());
    headers.set('X-Requested-With', 'SleepNova-Client');
    if (options.body && !headers.has('Content-Type') && !(options.body instanceof FormData)) {
      headers.set('Content-Type', 'application/json');
    }
    const res = await fetch(url, { ...options, headers });
    const data = await res.json();
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || 'Request failed');
    }
    return data;
  },
};
