"""Unit tests for SleepNova analytics, circular bedtime consistency, and executive summaries."""

from datetime import date, timedelta
import unittest

import config
from backend.analytics import compute_consistency_metrics, compute_executive_summary
from backend.sleep_logic import create_record_object


class TestAnalytics(unittest.TestCase):
    def test_empty_records_handled_without_fabrication(self) -> None:
        summary = compute_executive_summary([], dict(config.DEFAULT_SETTINGS))
        self.assertEqual(summary["overall"]["stats"]["record_count"], 0)
        self.assertFalse(summary["overall"]["consistency"]["sufficient_data"])
        self.assertEqual(summary["weekly"]["missing_days_count"], 7)

    def test_midnight_crossing_consistency_averaging(self) -> None:
        recs = [
            create_record_object("2026-11-18", "23:45", "2026-11-19", "07:45").to_dict(),
            create_record_object("2026-11-19", "00:15", "2026-11-20", "08:15").to_dict(),
        ]
        cons = compute_consistency_metrics(recs)
        self.assertTrue(cons["sufficient_data"])
        self.assertEqual(cons["average_bedtime"], "00:00")
        self.assertGreaterEqual(cons["consistency_score"], 80)

    def test_weekly_and_monthly_aggregations(self) -> None:
        today = date(2026, 11, 23)
        recs = []
        for i in range(1, 11):
            w_day = today - timedelta(days=i)
            s_day = w_day - timedelta(days=1)
            recs.append(
                create_record_object(
                    s_day.isoformat(), "22:30", w_day.isoformat(), "06:30"
                ).to_dict()
            )
        summary = compute_executive_summary(recs, dict(config.DEFAULT_SETTINGS), reference_date=today)
        self.assertEqual(summary["weekly"]["stats"]["record_count"], 6)
        self.assertEqual(summary["monthly"]["stats"]["record_count"], 10)
        self.assertEqual(summary["overall"]["stats"]["average_hours"], 8.0)


if __name__ == "__main__":
    unittest.main()
