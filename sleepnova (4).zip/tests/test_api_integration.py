"""Integration tests for Python bridge lifecycle, warning engine, charts, reports, and CLI."""

from __future__ import annotations

import base64
from datetime import date, timedelta
import io
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import backend.bridge as bridge
import backend.warnings as warnings_mod
import cli
import config


class TestBridgeAndIntegration(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.tmp_dir = Path(self.tmp.name)
        self.data_dir = self.tmp_dir / "data"
        self.exports_dir = self.tmp_dir / "exports"
        self.logs_dir = self.tmp_dir / "logs"
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)

        self.patches = [
            patch.object(config, "DATA_DIR", self.data_dir),
            patch.object(config, "EXPORTS_DIR", self.exports_dir),
            patch.object(config, "LOGS_DIR", self.logs_dir),
            patch.object(config, "RECORDS_JSON_PATH", self.data_dir / "sleep_records.json"),
            patch.object(config, "RECORDS_CSV_PATH", self.data_dir / "sleep_records.csv"),
            patch.object(config, "SETTINGS_JSON_PATH", self.data_dir / "settings.json"),
        ]
        for p in self.patches:
            p.start()

    def tearDown(self) -> None:
        for p in reversed(self.patches):
            p.stop()
        self.tmp.cleanup()

    def test_full_bridge_crud_analytics_reports_and_charts(self) -> None:
        # 1. Health check triggers cold-start demo seeding
        health = bridge.dispatch("health", {})
        self.assertTrue(health["ok"])
        self.assertEqual(health["record_count"], 39)

        # 2. Clear and add custom overnight record
        cleared = bridge.dispatch("clear_records", {})
        self.assertEqual(cleared["removed_count"], 39)

        today = date.today()
        yesterday = today - timedelta(days=1)
        created = bridge.dispatch(
            "create_record",
            {
                "sleep_date": yesterday.isoformat(),
                "bedtime": "22:45",
                "wake_date": today.isoformat(),
                "wake_time": "06:45",
                "notes": "Bridge integration test",
            },
        )
        rec = created["record"]
        self.assertEqual(rec["duration_minutes"], 480)

        # 3. Search & Pagination
        listed = bridge.dispatch("list_records", {"keyword": "Bridge", "page": 1, "page_size": 10})
        self.assertEqual(listed["total"], 1)

        # 4. Update & Delete
        updated = bridge.dispatch(
            "update_record",
            {
                "id": rec["id"],
                "sleep_date": yesterday.isoformat(),
                "bedtime": "22:30",
                "wake_date": today.isoformat(),
                "wake_time": "07:00",
                "notes": "Updated bridge test",
            },
        )
        self.assertEqual(updated["record"]["duration_minutes"], 510)

        # 5. Analytics summary includes insights & goal progress
        summary = bridge.dispatch("analytics_summary", {})
        self.assertEqual(summary["data_quality"]["total_records"], 1)
        self.assertEqual(summary["overall"]["stats"]["record_count"], 1)
        self.assertTrue(len(summary["insights"]) >= 1)
        self.assertEqual(len(summary["goal_progress_weekly"]), 4)
        self.assertIn("goal_completion", summary["methodology"])

        # 6. Settings save & retrieve
        saved_settings = bridge.dispatch("save_settings", {"sleep_goal_hours": 7.5, "preferred_date_format": "MM/DD/YYYY"})
        self.assertEqual(saved_settings["settings"]["sleep_goal_hours"], 7.5)
        self.assertEqual(saved_settings["settings"]["preferred_date_format"], "MM/DD/YYYY")

        # 7. All 5 report export formats (csv, json, markdown, txt, png)
        for fmt in ("csv", "json", "markdown", "txt", "png"):
            rep = bridge.dispatch("export_report", {"period": "all", "format": fmt})
            if fmt == "png":
                self.assertTrue(rep["is_binary"])
                png_bytes = base64.b64decode(rep["base64"])
                self.assertTrue(png_bytes.startswith(b"\x89PNG\r\n\x1a\n"))
            else:
                self.assertFalse(rep["is_binary"])
                self.assertTrue(len(rep["content"]) > 10)

        # 8. All 5 standalone chart kinds
        for chart_kind in ("weekly_trend", "monthly_trend", "duration_distribution", "goal_progress", "consistency_trend"):
            chart = bridge.dispatch("generate_chart", {"chart_kind": chart_kind})
            png_bytes = base64.b64decode(chart["base64"])
            self.assertTrue(png_bytes.startswith(b"\x89PNG\r\n\x1a\n"))

        # 8b. Dry-run CSV import preview must not mutate stored record count
        preview_csv = (
            "sleep_date,bedtime,wake_date,wake_time,notes\n"
            "2026-10-05,22:30,2026-10-06,06:30,Bridge preview candidate\n"
        )
        preview_res = bridge.dispatch("import_csv", {"csv_content": preview_csv, "preview_only": True})
        self.assertTrue(preview_res["preview_only"])
        self.assertEqual(preview_res["imported_count"], 1)
        after_preview = bridge.dispatch("list_records", {})
        self.assertEqual(after_preview["total"], 1)

        # 9. Delete record & verify KeyError on second delete
        deleted = bridge.dispatch("delete_record", {"id": rec["id"]})
        self.assertEqual(deleted["deleted"]["id"], rec["id"])
        with self.assertRaises(KeyError):
            bridge.dispatch("delete_record", {"id": rec["id"]})

    def test_warnings_engine_all_branches(self) -> None:
        settings = dict(config.DEFAULT_SETTINGS)
        ref = date(2026, 11, 20)

        # Empty state
        empty_w = warnings_mod.evaluate_warnings([], settings, reference_date=ref)
        self.assertEqual(empty_w[0]["id"], "no-records")

        # Short + Long + Variance + Gap + Goal deviation
        records = [
            {
                "id": "SLP-1",
                "sleep_date": "2026-11-10",
                "bedtime": "21:30",
                "wake_date": "2026-11-11",
                "wake_time": "02:00",
                "duration_minutes": 270,
                "duration_hours": 4.5,
            },
            {
                "id": "SLP-2",
                "sleep_date": "2026-11-11",
                "bedtime": "02:30",
                "wake_date": "2026-11-11",
                "wake_time": "14:00",
                "duration_minutes": 690,
                "duration_hours": 11.5,
            },
            {
                "id": "SLP-3",
                "sleep_date": "2026-11-12",
                "bedtime": "23:45",
                "wake_date": "2026-11-13",
                "wake_time": "04:45",
                "duration_minutes": 300,
                "duration_hours": 5.0,
            },
        ]
        found = warnings_mod.evaluate_warnings(records, settings, reference_date=ref)
        ids = {w["id"] for w in found}
        self.assertIn("short-sessions", ids)
        self.assertIn("long-sessions", ids)
        self.assertIn("logging-gap", ids)
        self.assertIn("bedtime-variance", ids)

        # Nominal state
        nominal_records = [
            {
                "id": f"SLP-{i}",
                "sleep_date": (ref - timedelta(days=i + 1)).isoformat(),
                "bedtime": "22:30",
                "wake_date": (ref - timedelta(days=i)).isoformat(),
                "wake_time": "06:30",
                "duration_minutes": 480,
                "duration_hours": 8.0,
            }
            for i in range(4)
        ]
        nom = warnings_mod.evaluate_warnings(nominal_records, settings, reference_date=ref)
        self.assertEqual(nom[0]["id"], "all-nominal")

    def test_cli_non_interactive_menu_flow(self) -> None:
        bridge.dispatch("health", {})
        # Invoke Daily (6), Weekly (7), Monthly (8), Executive (9), Chart (10 -> 4), Exit (13)
        inputs = iter(["6", "7", "8", "9", "10", "4", "13"])
        stdout = io.StringIO()
        with patch("builtins.input", lambda _prompt="": next(inputs)), patch("sys.stdout", stdout):
            cli.main()
        output = stdout.getvalue()
        self.assertIn("Daily Summary", output)
        self.assertIn("Weekly Summary", output)
        self.assertIn("Monthly Summary", output)
        self.assertIn("Executive Summary", output)
        self.assertIn("[Chart Saved]", output)
        self.assertIn("Thank you for using SleepNova", output)

    def test_flask_app_availability_diagnostic(self) -> None:
        try:
            import app as flask_module  # type: ignore
        except ImportError:
            # Flask is not installed in the container Python environment; verify syntax & report explicitly
            source = Path("app.py").read_text(encoding="utf-8")
            compile(source, "app.py", "exec")
            self.assertIn("/api/records", source)
            return

        client = flask_module.app.test_client()
        resp = client.get("/api/health")
        self.assertEqual(resp.status_code, 200)


if __name__ == "__main__":
    unittest.main()
