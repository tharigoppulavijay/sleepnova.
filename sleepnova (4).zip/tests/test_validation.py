"""Unit tests for SleepNova defensive validation and duplicate detection."""

from datetime import date, timedelta
import unittest

from backend.validation import (
    ValidationError,
    sanitize_csv_cell,
    validate_date,
    validate_settings,
    validate_sleep_record_input,
    validate_time,
)


class TestValidation(unittest.TestCase):
    def test_valid_12h_and_24h_times(self) -> None:
        self.assertEqual(validate_time("22:30", "Bedtime"), "22:30")
        self.assertEqual(validate_time("10:30 PM", "Bedtime"), "22:30")
        self.assertEqual(validate_time("12:15 AM", "Wake-up"), "00:15")

    def test_rejects_blank_and_invalid_inputs(self) -> None:
        with self.assertRaises(ValidationError):
            validate_date("", "Sleep Date")
        with self.assertRaises(ValidationError):
            validate_date("2026-02-30", "Sleep Date")
        with self.assertRaises(ValidationError):
            validate_time("25:99", "Bedtime")
        with self.assertRaises(ValidationError):
            validate_time("not-a-time", "Bedtime")

    def test_rejects_future_date(self) -> None:
        far_future = (date.today() + timedelta(days=5)).isoformat()
        with self.assertRaises(ValidationError):
            validate_date(far_future, "Sleep Date", allow_future=False)

    def test_rejects_over_24h_and_negative_duration(self) -> None:
        with self.assertRaises(ValidationError):
            validate_sleep_record_input(
                {
                    "sleep_date": "2026-11-18",
                    "bedtime": "22:00",
                    "wake_date": "2026-11-20",
                    "wake_time": "06:00",
                },
                allow_future=True,
            )
        with self.assertRaises(ValidationError):
            validate_sleep_record_input(
                {
                    "sleep_date": "2026-11-18",
                    "bedtime": "23:00",
                    "wake_date": "2026-11-18",
                    "wake_time": "06:00",
                },
                allow_future=True,
            )

    def test_duplicate_and_overlap_detection(self) -> None:
        existing = [
            {
                "id": "SLP-TEST-001",
                "sleep_date": "2026-11-18",
                "bedtime": "22:30",
                "wake_date": "2026-11-19",
                "wake_time": "06:30",
            }
        ]
        with self.assertRaises(ValidationError):
            validate_sleep_record_input(
                {
                    "sleep_date": "2026-11-18",
                    "bedtime": "22:30",
                    "wake_date": "2026-11-19",
                    "wake_time": "06:30",
                },
                existing_records=existing,
                allow_future=True,
            )
        with self.assertRaises(ValidationError):
            validate_sleep_record_input(
                {
                    "sleep_date": "2026-11-19",
                    "bedtime": "01:00",
                    "wake_date": "2026-11-19",
                    "wake_time": "07:00",
                },
                existing_records=existing,
                allow_future=True,
            )

    def test_csv_formula_sanitization_and_settings(self) -> None:
        self.assertEqual(sanitize_csv_cell("=CMD()"), "'=CMD()")
        self.assertEqual(sanitize_csv_cell(" =SUM(1,2)"), "' =SUM(1,2)")
        self.assertEqual(sanitize_csv_cell("\t@SUM(1,2)"), "'\t@SUM(1,2)")
        self.assertEqual(sanitize_csv_cell("Normal sleep note"), "Normal sleep note")
        settings = validate_settings({"sleep_goal_hours": 7.5, "short_sleep_threshold_hours": 5.0})
        self.assertEqual(settings["sleep_goal_hours"], 7.5)
        with self.assertRaises(ValidationError):
            validate_settings({"short_sleep_threshold_hours": 10.0, "long_sleep_threshold_hours": 8.0})

    def test_leap_year_date_validation(self) -> None:
        self.assertEqual(validate_date("2024-02-29", "Sleep Date", allow_future=True), "2024-02-29")
        with self.assertRaises(ValidationError):
            validate_date("2026-02-29", "Sleep Date", allow_future=True)


if __name__ == "__main__":
    unittest.main()
